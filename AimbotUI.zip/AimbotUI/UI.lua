--[[
  Aimbot UI - Window + widgets

  A fully customizable window:
    * drag the title bar to move, drag the bottom-right grip to resize
    * scale, opacity, background / border / accent colors, text size, lock
  Layout
    * grouped sidebar with an on/off dot per module
    * every tab has a pinned header (title, description, enable switch, reset)
    * settings live in cards; rows stretch with the window, so resizing is clean
  Everything is built from plain frames and textures (no Blizzard templates),
  so it can't break when the client changes its templates.
]]

local ADDON_NAME, NS = ...
local UI = {}
NS.UI = UI

local FONT  = STANDARD_TEXT_FONT
local WHITE = "Interface\\Buttons\\WHITE8X8"

local ROUND = "Interface\\AddOns\\" .. ADDON_NAME .. "\\media\\ui\\circle"

local SIDEBAR_W = 245
local HEADER_H  = 84

local texts   = setmetatable({}, { __mode = "k" })  -- fontstring -> size offset
local accents = setmetatable({}, { __mode = "k" })  -- texture    -> alpha multiplier
local roles   = setmetatable({}, { __mode = "k" })  -- fontstring -> "body" | "muted" (follows the text colors)
local rounds  = setmetatable({}, { __mode = "k" })  -- round textures: coloured with SetVertexColor
local pages   = {}
local tabs    = {}
local tabList = {}
local win, content, sidebar, titleBar, titleBG, bgTex, sideBG, grip
local FOOTER_H = 36
local borderEdges = {}
local edgeVertical = {}     -- border edge texture -> true for the left / right edges
local underlines = {}       -- the short accent lines under each tab title
local currentTab
UI._t_tabs = tabs        -- for the offline tests
UI._t_current = function() return currentTab end

local function W() return NS.db.window end

-- Window fonts. "default" is the game's own font; the rest are game fonts that every client has,
-- plus the fonts that ship with Aimbot UI.
local MEDIA = "Interface\\AddOns\\" .. ADDON_NAME .. "\\media\\fonts\\"
UI.FONTS = {
    { "default",  "Game default" },
    { "friz",     "Friz Quadrata", "Fonts\\FRIZQT__.TTF" },
    { "arial",    "Arial Narrow",  "Fonts\\ARIALN.TTF" },
    { "skurri",   "Skurri",        "Fonts\\skurri.ttf" },
    { "morpheus", "Morpheus",      "Fonts\\MORPHEUS.TTF" },
    { "damage1",  "Pepsi (Aimbot UI)",  MEDIA .. "damage1.ttf" },
    { "damage4",  "Bold (Aimbot UI)",   MEDIA .. "damage4.ttf" },
}
local function Font()
    local id = NS.db and W().font
    for _, f in ipairs(UI.FONTS) do
        if f[1] == id and f[3] then return f[3] end
    end
    return FONT
end
local function Flags()
    local o = NS.db and W().fontOutline
    if o == "OUTLINE" or o == "THICKOUTLINE" then return o end
    return ""
end
-- Sets a font, falling back to the game font if the chosen file can't be used.
local function SetFontSafe(fs, size)
    local ok, done = pcall(fs.SetFont, fs, Font(), size, Flags())
    if not ok or done == false then pcall(fs.SetFont, fs, FONT, size, Flags()) end
    if fs.SetShadowOffset then
        local sh = NS.db and W().textShadow
        pcall(fs.SetShadowOffset, fs, sh and 1 or 0, sh and -1 or 0)
        if fs.SetShadowColor then pcall(fs.SetShadowColor, fs, 0, 0, 0, sh and 1 or 0) end
    end
end
UI.SetFontSafe = SetFontSafe

----------------------------------------------------------------------
-- Primitives
----------------------------------------------------------------------
function UI.Text(parent, text, offset, r, g, b)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    local size = (NS.db and W().fontSize or 12) + (offset or 0)
    SetFontSafe(fs, size)
    fs:SetJustifyH("LEFT")
    if r == nil then
        roles[fs] = "body"
        local c = (NS.db and W().text) or { 0.90, 0.90, 0.92 }
        fs:SetTextColor(c[1], c[2], c[3])
    elseif r == 0.62 and g == 0.62 and b == 0.67 then
        roles[fs] = "muted"       -- the standard grey used for notes and descriptions
        local c = (NS.db and W().muted) or { 0.62, 0.62, 0.67 }
        fs:SetTextColor(c[1], c[2], c[3])
    else
        fs:SetTextColor(r, g, b)
    end
    fs:SetText(text or "")
    texts[fs] = offset or 0
    return fs
end

-- Paint a texture with a flat colour. Round textures keep their shape and are tinted instead.
local function Paint(tex, r, g, b, a)
    if rounds[tex] then tex:SetVertexColor(r, g, b, a or 1) else tex:SetColorTexture(r, g, b, a or 1) end
end
UI.Paint = Paint

-- A round (circle) texture. If the image can't be found (it needs a full game restart the
-- first time), it falls back to a plain square so nothing goes missing.
function UI.Round(parent, layer, size)
    local t = parent:CreateTexture(nil, layer or "ARTWORK")
    local ok, loaded = pcall(t.SetTexture, t, ROUND)
    if ok and loaded ~= false then
        rounds[t] = true
    else
        t:SetColorTexture(1, 1, 1, 1)
    end
    if size then t:SetSize(size, size) end
    return t
end

-- Classic WoW style (set once when the window is built; switching style needs a /reload).
UI.classic = false
-- Sharp style (2.20.0): a compact modern look. Settings in two columns, a module's areas as tabs
-- along the top, on/off buttons in the side menu, smaller text. Also set once at build time.
UI.sharp = false
local function LabelOff() return UI.sharp and -1 or 0 end
local function RowH(h) return UI.sharp and (h - 2) or h end
local SHARP_TWO_COL = 470        -- inner width a section needs before it splits into two columns
local SHARP_BAR_H = 32           -- height of a section's header bar
local SHARP_SECTION_GAP = 18     -- space between one section and the next
local GOLD = { 1, 0.82, 0 }

-- Classic window borders and backgrounds.
local CLASSIC_BORDERS = {
    stone   = { file = "Interface\\DialogFrame\\UI-DialogBox-Border", size = 32, inset = 11, out = 9 },
    gold    = { file = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border", size = 32, inset = 11, out = 9 },
    tooltip = { file = "Interface\\Tooltips\\UI-Tooltip-Border", size = 16, inset = 4, out = 3 },
    none    = { file = nil, size = 0, inset = 0, out = 0 },
}
local CLASSIC_BACKS = {
    dark   = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    rock   = "Interface\\FrameGeneral\\UI-Background-Rock",
    marble = "Interface\\FrameGeneral\\UI-Background-Marble",
    plain  = WHITE,
}

-- Put a game texture on tex. Returns false (and paints the fallback colour) if it can't load.
local function Art(tex, file, r, g, b, a)
    local ok, loaded = pcall(tex.SetTexture, tex, file)
    if ok and loaded ~= false then return true end
    tex:SetColorTexture(r or 0, g or 0, b or 0, a or 0.6)
    return false
end
UI.Art = Art

-- A frame (or slider) that can take a Blizzard-style backdrop; plain frame if the template is missing.
local function BackdropFrame(kind, parent)
    local ok, f = pcall(CreateFrame, kind or "Frame", nil, parent, "BackdropTemplate")
    if ok and f then return f end
    return CreateFrame(kind or "Frame", nil, parent)
end

local function SetBackdrop(f, def)
    if not (f and f.SetBackdrop) then return false end
    return pcall(f.SetBackdrop, f, def)
end

function UI.Accent(tex, mult)
    accents[tex] = mult or 1
    local c = W().accent
    Paint(tex, c[1], c[2], c[3], (c[4] or 1) * (mult or 1))
end

local function RestyleTexts()
    local base = W().fontSize
    local body, muted = W().text, W().muted
    for fs, offset in pairs(texts) do
        SetFontSafe(fs, base + offset)
        local role = roles[fs]
        if role == "body" then fs:SetTextColor(body[1], body[2], body[3])
        elseif role == "muted" then fs:SetTextColor(muted[1], muted[2], muted[3]) end
    end
end

local function RestyleAccents()
    local c = W().accent
    for tex, mult in pairs(accents) do
        Paint(tex, c[1], c[2], c[3], (c[4] or 1) * mult)
    end
end

-- Four 1px edges around a frame. Returns the list so callers can recolor.
local function Edges(frame, r, g, b, a, layer)
    local list = {}
    local function E(p1, p2, w, h)
        local t = frame:CreateTexture(nil, layer or "BORDER")
        t:SetColorTexture(r, g, b, a)
        t:SetPoint(p1); t:SetPoint(p2)
        if w then t:SetWidth(w) end
        if h then t:SetHeight(h) end
        table.insert(list, t)
    end
    E("TOPLEFT", "TOPRIGHT", nil, 1)
    E("BOTTOMLEFT", "BOTTOMRIGHT", nil, 1)
    E("TOPLEFT", "BOTTOMLEFT", 1, nil)
    E("TOPRIGHT", "BOTTOMRIGHT", 1, nil)
    return list
end

local function Tip(frame, title, text)
    if not text or text == "" then return end
    frame:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(title or "", 1, 1, 1)
        GameTooltip:AddLine(text, 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    frame:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

-- A label that may be cut short (narrow columns): hovering it shows the whole text when it is.
local function LabelTip(parent, fs, text)
    if not (UI.sharp and type(text) == "string" and text ~= "") then return end
    local hot = CreateFrame("Frame", nil, parent)
    hot:SetAllPoints(fs)
    hot:EnableMouse(true)
    if hot.SetMouseClickEnabled then pcall(hot.SetMouseClickEnabled, hot, false) end
    hot:SetScript("OnEnter", function(self)
        local ok, cut = pcall(fs.IsTruncated, fs)
        if not (ok and cut) then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(text, 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    hot:SetScript("OnLeave", function() GameTooltip:Hide() end)
end
UI._LabelTip = LabelTip

-- Flat button: soft fill, a faint top light, accent wash on hover.
local function ClassicButton(parent, label, width, height)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width or 120, height or 22)
    local function Part(layer, file)
        local t = b:CreateTexture(nil, layer)
        t:SetAllPoints()
        if Art(t, file, 0.45, 0.06, 0.04, 1) then t:SetTexCoord(0, 0.625, 0, 0.6875) end
        return t
    end
    local up = Part("BACKGROUND", "Interface\\Buttons\\UI-Panel-Button-Up")
    local down = Part("BACKGROUND", "Interface\\Buttons\\UI-Panel-Button-Down")
    down:Hide()
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    if Art(hl, "Interface\\Buttons\\UI-Panel-Button-Highlight", 1, 1, 1, 0.12) then
        hl:SetTexCoord(0, 0.625, 0, 0.6875)
        hl:SetBlendMode("ADD")
    end
    local fs = UI.Text(b, label, -1, GOLD[1], GOLD[2], GOLD[3])
    fs:SetPoint("CENTER", 0, 1)
    fs:SetJustifyH("CENTER")
    b.label = fs
    b:SetScript("OnMouseDown", function() up:Hide(); down:Show(); fs:SetPoint("CENTER", 1, 0) end)
    b:SetScript("OnMouseUp", function() down:Hide(); up:Show(); fs:SetPoint("CENTER", 0, 1) end)
    b:HookScript("OnEnter", function() fs:SetTextColor(1, 1, 1) end)
    b:HookScript("OnLeave", function() fs:SetTextColor(GOLD[1], GOLD[2], GOLD[3]) end)
    return b
end

function UI.MakeButton(parent, label, width, height)
    if UI.classic then return ClassicButton(parent, label, width, height) end
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width or 120, height or 22)
    local fill = b:CreateTexture(nil, "BACKGROUND")
    fill:SetAllPoints()
    fill:SetColorTexture(1, 1, 1, 0.07)
    local top = b:CreateTexture(nil, "BORDER")
    top:SetPoint("TOPLEFT"); top:SetPoint("TOPRIGHT")
    top:SetHeight(1)
    top:SetColorTexture(1, 1, 1, 0.06)
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    UI.Accent(hl, 0.28)
    local fs = UI.Text(b, label, -1)
    fs:SetPoint("CENTER")
    fs:SetJustifyH("CENTER")
    b.label = fs
    b:SetScript("OnMouseDown", function() fill:SetColorTexture(0, 0, 0, 0.25) end)
    b:SetScript("OnMouseUp",   function() fill:SetColorTexture(1, 1, 1, 0.07) end)
    return b
end

----------------------------------------------------------------------
-- Color picker (supports both the new and the old ColorPickerFrame API)
----------------------------------------------------------------------
function UI.PickColor(r, g, b, a, onChange)
    local function Current()
        local nr, ng, nb = ColorPickerFrame:GetColorRGB()
        local na = a
        if ColorPickerFrame.GetColorAlpha then
            na = ColorPickerFrame:GetColorAlpha()
        elseif OpacitySliderFrame and OpacitySliderFrame.GetValue then
            na = 1 - OpacitySliderFrame:GetValue()
        end
        return nr, ng, nb, na
    end
    local function Changed() onChange(Current()) end
    local function Cancelled() onChange(r, g, b, a) end

    if ColorPickerFrame.SetupColorPickerAndShow then
        ColorPickerFrame:SetupColorPickerAndShow({
            r = r, g = g, b = b, opacity = a, hasOpacity = true,
            swatchFunc = Changed, opacityFunc = Changed, cancelFunc = Cancelled,
        })
    else
        ColorPickerFrame:SetColorRGB(r, g, b)
        ColorPickerFrame.hasOpacity = true
        ColorPickerFrame.opacity = 1 - a
        ColorPickerFrame.previousValues = { r, g, b, 1 - a }
        ColorPickerFrame.func = Changed
        ColorPickerFrame.opacityFunc = Changed
        ColorPickerFrame.cancelFunc = Cancelled
        ColorPickerFrame:Hide()
        ColorPickerFrame:Show()
    end
end

----------------------------------------------------------------------
-- Switch (on/off pill). Used by every checkbox-style setting.
----------------------------------------------------------------------
-- Toggle switch: a pill-shaped track (two round ends and a middle) with a round knob.
local function MakeSwitch(parent, get, set)
    local sw = CreateFrame("Button", nil, parent)
    sw:SetSize(36, 18)
    local capL = UI.Round(sw, "BACKGROUND", 18)
    capL:SetPoint("LEFT", sw, "LEFT", 0, 0)
    local capR = UI.Round(sw, "BACKGROUND", 18)
    capR:SetPoint("RIGHT", sw, "RIGHT", 0, 0)
    local mid = sw:CreateTexture(nil, "BACKGROUND")
    mid:SetPoint("TOPLEFT", sw, "TOPLEFT", 9, 0)
    mid:SetPoint("BOTTOMRIGHT", sw, "BOTTOMRIGHT", -9, 0)
    local knob = UI.Round(sw, "ARTWORK", 14)
    local glow = UI.Round(sw, "HIGHLIGHT", 22)
    glow:SetPoint("CENTER", knob, "CENTER", 0, 0)
    Paint(glow, 1, 1, 1, 0.10)

    local function Track(r, g, b, a)
        Paint(capL, r, g, b, a); Paint(capR, r, g, b, a); Paint(mid, r, g, b, a)
    end
    function sw.Refresh()
        local on = get() and true or false
        knob:ClearAllPoints()
        if on then
            local c = W().accent
            Track(c[1], c[2], c[3], 1)
            Paint(knob, 1, 1, 1, 1)
            knob:SetPoint("RIGHT", sw, "RIGHT", -2, 0)
        else
            Track(0.22, 0.22, 0.25, 1)
            Paint(knob, 0.62, 0.62, 0.66, 1)
            knob:SetPoint("LEFT", sw, "LEFT", 2, 0)
        end
    end
    sw:SetScript("OnClick", function()
        set(not get())
        UI.RefreshAll()
    end)
    sw.Refresh()
    return sw
end

-- Blizzard checkbox (classic style). Same interface as a switch: .Refresh().
local function MakeCheck(parent, get, set)
    local cb = CreateFrame("Button", nil, parent)
    cb:SetSize(24, 24)
    local up = cb:CreateTexture(nil, "ARTWORK")
    up:SetAllPoints()
    if not Art(up, "Interface\\Buttons\\UI-CheckBox-Up", 0, 0, 0, 0.6) then
        up:ClearAllPoints(); up:SetPoint("CENTER"); up:SetSize(16, 16)
    end
    local hl = cb:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    if Art(hl, "Interface\\Buttons\\UI-CheckBox-Highlight", 1, 1, 1, 0.12) then hl:SetBlendMode("ADD") end
    local chk = cb:CreateTexture(nil, "OVERLAY")
    chk:SetAllPoints()
    if not Art(chk, "Interface\\Buttons\\UI-CheckBox-Check", GOLD[1], GOLD[2], GOLD[3], 1) then
        chk:ClearAllPoints(); chk:SetPoint("CENTER"); chk:SetSize(10, 10)
    end
    function cb.Refresh() chk:SetShown(get() and true or false) end
    cb:SetScript("OnClick", function()
        set(not get())
        UI.RefreshAll()
    end)
    cb.Refresh()
    return cb
end

local function Toggle(parent, get, set)
    if UI.classic then return MakeCheck(parent, get, set) end
    return MakeSwitch(parent, get, set)
end

----------------------------------------------------------------------
-- Page: a scrollable column of cards
----------------------------------------------------------------------
local Page = {}
Page.__index = Page

local function MakeScrollbar(parent, sf)
    local bar = CreateFrame("Frame", nil, parent)
    bar:SetWidth(4)
    bar:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -3, -4)
    bar:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -2, 4)
    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetAllPoints()
    track:SetColorTexture(1, 1, 1, 0.03)
    local thumb = CreateFrame("Button", nil, bar)
    thumb:SetWidth(4)
    local tex = thumb:CreateTexture(nil, "ARTWORK")
    tex:SetAllPoints()
    UI.Accent(tex, 0.55)
    bar.thumb = thumb
    bar:Hide()

    local dragging, startY, startScroll
    local function Update()
        local range = sf:GetVerticalScrollRange() or 0
        local vis = sf:GetHeight() or 1
        if range < 1 then bar:Hide(); return end
        bar:Show()
        local total = vis + range
        local th = math.max(28, vis * vis / total)
        local free = math.max(1, bar:GetHeight() - th)
        local pos = (sf:GetVerticalScroll() / range) * free
        thumb:SetHeight(th)
        thumb:ClearAllPoints()
        thumb:SetPoint("TOP", bar, "TOP", 0, -pos)
    end
    bar.Update = Update

    thumb:SetScript("OnMouseDown", function()
        dragging = true
        startY = select(2, GetCursorPosition()) / sf:GetEffectiveScale()
        startScroll = sf:GetVerticalScroll()
    end)
    thumb:SetScript("OnMouseUp", function() dragging = false end)
    thumb:SetScript("OnUpdate", function()
        if not dragging then return end
        local range = sf:GetVerticalScrollRange() or 0
        local free = math.max(1, bar:GetHeight() - thumb:GetHeight())
        local y = select(2, GetCursorPosition()) / sf:GetEffectiveScale()
        local v = startScroll + (startY - y) / free * range
        sf:SetVerticalScroll(math.max(0, math.min(range, v)))
    end)
    return bar
end

function UI.NewPage(parent)
    local sf = CreateFrame("ScrollFrame", nil, parent)
    sf:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 0)
    sf:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -12, 0)
    local child = CreateFrame("Frame", nil, sf)
    child:SetSize(500, 10)
    sf:SetScrollChild(child)
    sf:EnableMouseWheel(true)
    sf:Hide()

    local p = setmetatable({
        frame = sf, child = child, cards = {}, refreshers = {},
    }, Page)
    p.bar = MakeScrollbar(parent, sf)
    p.bar:Hide()

    sf:SetScript("OnMouseWheel", function(self, delta)
        local range = self:GetVerticalScrollRange() or 0
        self:SetVerticalScroll(math.max(0, math.min(range, self:GetVerticalScroll() - delta * 56)))
    end)
    sf:SetScript("OnVerticalScroll", function() p.bar.Update() end)
    sf:SetScript("OnScrollRangeChanged", function() p.bar.Update() end)
    sf:SetScript("OnSizeChanged", function(_, w)
        if w and w > 0 then child:SetWidth(w) end
        p:Reflow()
    end)

    table.insert(pages, p)
    return p
end

-- A page with three or more sections shows one area at a time, chosen from the side menu
-- dropdown. "Pinned" sections (previews) stay on screen.

local function CardShown(self, card)
    if card.pinned or not self.menuMode then return true end
    return self.view == card
end

local function LayoutCard(self, card, y, cw)
    card.frame:Show()
    card.frame:ClearAllPoints()
    card.frame:SetPoint("TOPLEFT", self.child, "TOPLEFT", 4, -y)
    card.frame:SetPoint("TOPRIGHT", self.child, "TOPRIGHT", -4, -y)
    local iy = card.title and (card.descText and (UI.classic and 62 or 60) or (UI.classic and 46 or 44)) or 14
    local innerW = cw - 8 - 32
    for _, row in ipairs(card.rows) do
        local h = row.height(innerW)
        row.frame:ClearAllPoints()
        row.frame:SetPoint("TOPLEFT", card.frame, "TOPLEFT", 16, -iy)
        row.frame:SetPoint("TOPRIGHT", card.frame, "TOPRIGHT", -16, -iy)
        row.frame:SetHeight(h)
        iy = iy + h + 8
    end
    card.frame:SetHeight(iy + 8)
    return iy + 8 + 14
end

-- Sharp style: switches, sliders, colours and dropdowns sit two to a line when the section is wide
-- enough; notes, buttons, text boxes and lists always take the whole width.
local function LayoutCardSharp(self, card, y, cw)
    card.frame:Show()
    card.frame:ClearAllPoints()
    card.frame:SetPoint("TOPLEFT", self.child, "TOPLEFT", 4, -y)
    card.frame:SetPoint("TOPRIGHT", self.child, "TOPRIGHT", -4, -y)
    local PAD, GAP, VGAP = 14, 28, 6
    local iy = card.title and (SHARP_BAR_H + 12) or 12
    local innerW = cw - 8 - PAD * 2
    if card.fold then
        -- folded away: just the header bar
        local folded = UI.IsFolded(self, card)
        card.foldText:SetText(folded and "+" or "-")
        if not card.foldWired then
            card.foldWired = true
            card.fold:SetScript("OnClick", function()
                UI.SetFolded(self, card, not UI.IsFolded(self, card))
                self:Reflow()
            end)
            Tip(card.fold, card.title or "Section", "Click to fold this section away or open it again.")
        end
        if folded then
            for _, row in ipairs(card.rows) do row.frame:Hide() end
            for _, d in ipairs(card.dividers or {}) do d:Hide() end
            card.frame:SetHeight(SHARP_BAR_H + 1)
            return SHARP_BAR_H + 1 + SHARP_SECTION_GAP
        end
    end
    local two = innerW >= SHARP_TWO_COL
    local colW = two and math.floor((innerW - GAP) / 2) or innerW
    card.columns = two and 2 or 1
    local lineH                       -- height of the line whose left column is filled, waiting for a right one
    card.dividers = card.dividers or {}
    local nDiv = 0
    local function Divider(atY)
        nDiv = nDiv + 1
        local d = card.dividers[nDiv]
        if not d then
            d = card.frame:CreateTexture(nil, "BORDER")
            d:SetHeight(1)
            d:SetColorTexture(1, 1, 1, 0.04)
            card.dividers[nDiv] = d
        end
        d:ClearAllPoints()
        d:SetPoint("TOPLEFT", card.frame, "TOPLEFT", PAD, -atY)
        d:SetPoint("TOPRIGHT", card.frame, "TOPRIGHT", -PAD, -atY)
        d:Show()
    end
    local lines = 0
    local function EndLine(h)
        if lines > 0 then Divider(iy - math.floor(VGAP / 2) - 1) end
        lines = lines + 1
        iy = iy + h + VGAP
    end
    for _, row in ipairs(card.rows) do
        row.frame:ClearAllPoints()
        row.frame:Show()
        if two and row.half then
            local h = row.height(colW)
            if not lineH then
                row.frame:SetPoint("TOPLEFT", card.frame, "TOPLEFT", PAD, -iy)
                row.col = 1
                lineH = h
            else
                row.frame:SetPoint("TOPLEFT", card.frame, "TOPLEFT", PAD + colW + GAP, -iy)
                row.col = 2
                lineH = math.max(lineH, h)
                EndLine(lineH)
                lineH = nil
            end
            row.frame:SetWidth(colW)
            row.frame:SetHeight(h)
        else
            if lineH then EndLine(lineH); lineH = nil end
            local h = row.height(innerW)
            row.frame:SetPoint("TOPLEFT", card.frame, "TOPLEFT", PAD, -iy)
            row.frame:SetPoint("TOPRIGHT", card.frame, "TOPRIGHT", -PAD, -iy)
            row.frame:SetHeight(h)
            row.col = 0
            EndLine(h)
        end
    end
    if lineH then EndLine(lineH) end
    for i = nDiv + 1, #card.dividers do card.dividers[i]:Hide() end
    card.frame:SetHeight(iy + 6)
    return iy + 6 + SHARP_SECTION_GAP
end

-- Folded sections are remembered per tab and section name.
local function FoldKey(page, card) return (page.moduleKey or "general") .. "/" .. tostring(card.title) end
function UI.IsFolded(page, card)
    local w = W()
    return type(w.folded) == "table" and w.folded[FoldKey(page, card)] == true
end
function UI.SetFolded(page, card, v)
    local w = W()
    if type(w.folded) ~= "table" then w.folded = {} end
    w.folded[FoldKey(page, card)] = v and true or nil
end
UI._LayoutCardSharp = LayoutCardSharp

function Page:Reflow()
    local menu = self.menuMode
    -- visibility first, so it is right even before the window has a width
    for _, card in ipairs(self.cards) do
        if not CardShown(self, card) then card.frame:Hide() end
    end

    local cw = self.child:GetWidth()
    if not cw or cw < 80 then return end
    local y = 4

    -- pinned sections first, then the rest
    for pass = 1, 2 do
        for _, card in ipairs(self.cards) do
            if (pass == 1) == (card.pinned and true or false) then
                if CardShown(self, card) then
                    y = y + (UI.sharp and LayoutCardSharp or LayoutCard)(self, card, y, cw)
                else
                    card.frame:Hide()
                end
            end
        end
    end

    self.child:SetHeight(y + 4)
    if self.bar then self.bar.Update() end
end

function Page:Open(card)
    self.view = card
    if self.frame.SetVerticalScroll then self.frame:SetVerticalScroll(0) end
    self:Reflow()
    if self.onOpen then pcall(self.onOpen, card) end
    if UI.LayoutSidebar then UI.LayoutSidebar() end
end

function Page:Back() end     -- kept so older calls do nothing harmful; the side menu dropdown replaced it

----------------------------------------------------------------------
-- Sharp style: settings that belong together share one line (2.21.0)
--   * a colour right after a setting becomes a small swatch on that setting's line
--   * a "Show ..." switch right before a setting about the same thing becomes an eye on its line
--   * font / outline / shadow settings, and x / y offsets, go into a pop-out behind a gear button
-- Nothing is lost: every setting still works, refreshes, undoes and is found by search
-- (search opens the pop-out). Other styles keep the plain one-setting-per-line layout.
----------------------------------------------------------------------
local STOP = { show = true, the = true, your = true, with = true, when = true, from = true, that = true,
    this = true, colour = true, color = true, size = true, only = true, also = true, them = true,
    their = true, ["while"] = true, into = true, over = true, under = true, each = true }
local function Words(label)
    local t = {}
    for w in tostring(label or ""):lower():gmatch("%a+") do
        if #w >= 4 and not STOP[w] then t[(w:gsub("s$", ""))] = true end
    end
    return t
end
local function ShareWord(a, b)
    local wa = Words(a)
    for w in pairs(Words(b)) do if wa[w] then return true end end
    return false
end
UI._ShareWord = ShareWord

local function IsStyleLabel(l)
    l = tostring(l or ""):lower()
    return l:find("font") or l:find("outline") or l:find("shadow") or l:find("text size")
        or l:find("number size")
end
local function IsOffsetLabel(l)
    l = tostring(l or ""):lower()
    return l:find("offset") or l:find("left / right") or l:find("up / down") or l:find("horizontal")
        or l:find("vertical") or l:find("^x$") or l:find("^y$")
end
local function IsSizeLabel(l)
    l = tostring(l or ""):lower()
    return l == "width" or l == "height"
end

-- the leftmost thing on the right side of a line: new icons go just left of it
local function LeftEdge(row) return row.leftmost or row.ctrl end
local function PutLeft(row, obj, gap)
    obj:ClearAllPoints()
    if row.kind == "group" and not row.leftmost then gap = -1 end
    obj:SetPoint("RIGHT", LeftEdge(row), "LEFT", -(gap or 8), 0)
    row.leftmost = obj
    if row.fs then row.fs:SetPoint("RIGHT", obj, "LEFT", -10, 0) end
end

-- small icons drawn from plain textures
local function IconButton(parent, size)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(size or 18, size or 18)
    local hl = UI.Round(b, "HIGHLIGHT", (size or 18))
    hl:SetPoint("CENTER")
    Paint(hl, 1, 1, 1, 0.08)
    return b
end
local function SideFill() local c = W().bg; return c[1], c[2], c[3] end

function UI.MakeEye(parent)
    local b = IconButton(parent, 18)
    local outer = UI.Round(b, "ARTWORK", 14); outer:SetSize(15, 9); outer:SetPoint("CENTER")
    local inner = UI.Round(b, "ARTWORK", 10); inner:SetSize(11, 6); inner:SetPoint("CENTER")
    inner:SetDrawLayer("ARTWORK", 2)
    local pupil = UI.Round(b, "ARTWORK", 5); pupil:SetPoint("CENTER"); pupil:SetDrawLayer("ARTWORK", 3)
    local slash = b:CreateTexture(nil, "ARTWORK", nil, 4)
    slash:SetSize(2, 17); slash:SetPoint("CENTER")
    if slash.SetRotation then pcall(slash.SetRotation, slash, math.rad(45)) end
    function b.Set(on)
        local c = on and W().text or { 0.42, 0.42, 0.46 }
        Paint(outer, c[1], c[2], c[3], 1)
        Paint(pupil, c[1], c[2], c[3], 1)
        local r, g, bl = SideFill()
        Paint(inner, r, g, bl, 1)
        slash:SetColorTexture(c[1], c[2], c[3], 1)
        slash:SetShown(not on)
    end
    return b
end

function UI.MakeGear(parent)
    local b = IconButton(parent, 18)
    local parts = {}
    local body = UI.Round(b, "ARTWORK", 11); body:SetPoint("CENTER"); parts[#parts + 1] = body
    for i = 0, 7 do
        local tooth = b:CreateTexture(nil, "ARTWORK")
        tooth:SetSize(3, 3)
        local a = i * math.pi / 4
        tooth:SetPoint("CENTER", b, "CENTER", math.floor(math.cos(a) * 6 + 0.5), math.floor(math.sin(a) * 6 + 0.5))
        if tooth.SetRotation then pcall(tooth.SetRotation, tooth, a) end
        parts[#parts + 1] = tooth
    end
    local hole = UI.Round(b, "ARTWORK", 4); hole:SetPoint("CENTER"); hole:SetDrawLayer("ARTWORK", 2)
    function b.Set(active)
        local c = active and W().accent or W().muted
        for _, t in ipairs(parts) do
            if rounds[t] then Paint(t, c[1], c[2], c[3], 1) else t:SetColorTexture(c[1], c[2], c[3], 1) end
        end
        local r, g, bl = SideFill()
        Paint(hole, r, g, bl, 1)
    end
    return b
end

-- A colour row becomes a swatch on the line before it.
local function AttachSwatch(page, host, crow)
    local btn = crow.ctrl
    btn:SetParent(host.frame)
    btn:SetSize(16, 16)
    PutLeft(host, btn, 8)
    Tip(btn, crow.label or "Colour", "Click to pick a colour.")
    crow.host = host
    host.swatch = btn
end

-- A "Show ..." switch becomes an eye on the line after it; the line dims while it is off.
local function AttachEye(page, host, srow)
    local eye = UI.MakeEye(host.frame)
    PutLeft(host, eye, 8)
    local function refresh()
        local on = srow.get() and true or false
        eye.Set(on)
        host.frame:SetAlpha(on and 1 or 0.55)
    end
    eye:SetScript("OnClick", function() srow.set(not srow.get()); refresh() end)
    Tip(eye, srow.label or "Show", "Click to show or hide.")
    table.insert(page.refreshers, refresh)
    refresh()
    srow.host = host
    host.eye = eye
end

-- Pop-out panel for grouped settings, opened by a gear on the host line.
local openPop
function UI.ClosePops() if openPop then openPop:Hide(); openPop = nil end end
local POP_W = 300
local function MakePop(page, host, title, rows)
    local pop = CreateFrame("Frame", nil, win or UIParent)
    pop:SetFrameStrata("HIGH")
    pop:SetClampedToScreen(true)
    pop:EnableMouse(true)
    pop:Hide()
    local bg = pop:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    local edges = Edges(pop, 1, 1, 1, 1, "BORDER")
    for _, e in ipairs(edges) do UI.Accent(e, 0.45) end
    local head = UI.Text(pop, string.upper(title or "Options"), -2, 0.62, 0.62, 0.67)
    head:SetPoint("TOPLEFT", pop, "TOPLEFT", 14, -10)
    head:SetPoint("RIGHT", pop, "RIGHT", -34, 0)
    head:SetWordWrap(false)
    local x = CreateFrame("Button", nil, pop)
    x:SetSize(18, 18)
    x:SetPoint("TOPRIGHT", pop, "TOPRIGHT", -6, -6)
    local xt = UI.Text(x, "x", 0, 0.62, 0.62, 0.67)
    xt:SetPoint("CENTER", 0, 1)
    x:SetScript("OnClick", function() UI.ClosePops() end)
    pop.rows = rows
    for _, r in ipairs(rows) do
        r.frame:SetParent(pop)
        r.pop = pop
        r.host = host
    end
    function pop.Layout()
        local c = W().bg
        bg:SetColorTexture(c[1], c[2], c[3], 0.98)
        local y, inner = 30, POP_W - 28
        for _, r in ipairs(rows) do
            local h = r.height(inner)
            r.frame:ClearAllPoints()
            r.frame:SetPoint("TOPLEFT", pop, "TOPLEFT", 14, -y)
            r.frame:SetWidth(inner)
            r.frame:SetHeight(h)
            r.frame:Show()
            y = y + h + 6
        end
        pop:SetSize(POP_W, y + 6)
    end
    function pop.Open()
        if openPop and openPop ~= pop then openPop:Hide() end
        pop:ClearAllPoints()
        pop:SetPoint("TOPLEFT", host.gear, "BOTTOMRIGHT", 4, -2)
        pop.Layout()
        pop:Show()
        openPop = pop
        for _, fn in ipairs(page.refreshers) do pcall(fn) end
    end
    pop:SetScript("OnHide", function()
        if openPop == pop then openPop = nil end
        if host.gear then host.gear.Set(false) end
    end)
    pop:SetScript("OnShow", function() if host.gear then host.gear.Set(true) end end)
    return pop
end

local function AttachGear(page, host, rows, title)
    local gear = UI.MakeGear(host.frame)
    PutLeft(host, gear, 8)
    host.gear = gear
    local pop = MakePop(page, host, title, rows)
    host.popout = pop
    gear:SetScript("OnClick", function()
        if pop:IsShown() then pop:Hide() else pop.Open() end
    end)
    local names = {}
    for _, r in ipairs(rows) do names[#names + 1] = r.label or "?" end
    Tip(gear, title or "More options", table.concat(names, ", "))
    gear.Set(false)
    table.insert(page.refreshers, function() gear.Set(pop:IsShown()) end)
end

-- Runs once per page in Sharp style, before areas are decided.
function UI.GroupSharp(page)
    for _, card in ipairs(page.cards) do
        local rows = card.rows
        card.allRows = {}
        for i, r in ipairs(rows) do card.allRows[i] = r end
        local kept = {}
        -- 1. colours onto the line before
        for i, r in ipairs(rows) do
            local prev = kept[#kept]
            -- a run of several colours (one per state or resource) stays as it is
            local loneColour = r.kind == "color" and not (rows[i + 1] and rows[i + 1].kind == "color")
                and not (rows[i - 1] and rows[i - 1].kind == "color")
            if loneColour and prev and (prev.kind == "check" or prev.kind == "slider" or prev.kind == "cycle")
                and not prev.swatch then
                AttachSwatch(page, prev, r)
                r.frame:Hide()
            else
                kept[#kept + 1] = r
            end
        end
        rows = kept; kept = {}
        -- 2. "Show ..." switches as an eye on the next line about the same thing
        local i = 1
        while i <= #rows do
            local r, nxt = rows[i], rows[i + 1]
            local lbl = r.label and r.label:lower() or ""
            if r.kind == "check" and nxt and lbl:find("^show ") and not r.swatch
                and (nxt.kind == "slider" or nxt.kind == "cycle") and not nxt.eye
                and nxt.label and ShareWord(r.label:sub(6), nxt.label) then
                AttachEye(page, nxt, r)
                r.frame:Hide()
                i = i + 1
            else
                kept[#kept + 1] = r
                i = i + 1
            end
        end
        rows = kept; kept = {}
        -- 3. gear pop-outs: text style runs, then offset runs
        i = 1
        while i <= #rows do
            local r = rows[i]
            local run = {}
            local j = i
            while rows[j] and rows[j].half and IsStyleLabel(rows[j].label) do run[#run + 1] = rows[j]; j = j + 1 end
            if #run >= 2 then
                local host = run[1]
                local rest = {}
                for k = 2, #run do rest[#rest + 1] = run[k]; run[k].frame:Hide() end
                AttachGear(page, host, rest, "Text style")
                kept[#kept + 1] = host
                i = j
            else
                run = {}
                j = i
                local isSize = rows[j] and rows[j].kind == "slider" and IsSizeLabel(rows[j].label)
                local test = isSize and IsSizeLabel or IsOffsetLabel
                while rows[j] and rows[j].kind == "slider" and test(rows[j].label) do
                    run[#run + 1] = rows[j]; j = j + 1
                end
                if #run >= 2 then
                    local prev = kept[#kept]
                    local related = prev and prev.half and not prev.gear and prev.label
                        and (ShareWord(prev.label, run[1].label) or prev.label:lower():find("position"))
                    local host = related and prev or nil
                    local list = run
                    if not host and isSize then
                        host = run[1]
                        list = {}
                        for k = 2, #run do list[#list + 1] = run[k] end
                        kept[#kept + 1] = host
                    elseif not host then
                        -- a line of its own: "Position" with just the gear
                        local f = CreateFrame("Frame", nil, card.frame)
                        local fs = UI.Text(f, "Position", LabelOff())
                        fs:SetPoint("LEFT", f, "LEFT", 0, 0)
                        fs:SetWordWrap(false)
                        local stub = CreateFrame("Frame", nil, f)
                        stub:SetSize(1, 1)
                        stub:SetPoint("RIGHT", f, "RIGHT", 0, 0)
                        host = { frame = f, fs = fs, ctrl = stub, kind = "group", half = true,
                            height = function() return RowH(24) end }
                        kept[#kept + 1] = host
                    end
                    for _, x in ipairs(list) do x.frame:Hide() end
                    AttachGear(page, host, list, isSize and "Size" or "Position")
                    i = j
                else
                    kept[#kept + 1] = r
                    i = i + 1
                end
            end
        end
        card.rows = kept
    end
end

-- Called once after a module's Build(): decides whether this page gets the area list.
function Page:Finish()
    if UI.sharp and not self.grouped then
        self.grouped = true
        local ok, err = pcall(UI.GroupSharp, self)
        if not ok then NS.ReportError("settings layout", err) end
    end
    local areas = {}
    for _, card in ipairs(self.cards) do
        if card.title and not card.pinned and #card.rows > 0 then areas[#areas + 1] = card end
    end
    -- Sharp style (2.22.0): one long page, every section stacked under its own header bar
    if UI.sharp or #areas < 3 then self.menuMode = false; return end
    self.menuMode = true
    self.areas = areas

    -- No separate list of areas any more: the side menu dropdown does that job.
    -- The page always shows one area; the one marked { open = true } (or the first) to begin with.
    local first = areas[1]
    for _, card in ipairs(areas) do
        if card.openFirst then first = card; break end
    end
    self:Open(first)
end

function Page:Section(title, desc, opts)
    local f = CreateFrame("Frame", nil, self.child)
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    if UI.sharp then
        bg:SetColorTexture(1, 1, 1, 0.025)
        Edges(f, 1, 1, 1, 0.06, "BORDER")
    elseif UI.classic then
        bg:SetColorTexture(0, 0, 0, 0.22)
        Edges(f, 1, 1, 1, 0.06, "BORDER")
    else
        bg:SetColorTexture(1, 1, 1, 0.03)
        Edges(f, 1, 1, 1, 0.055, "BORDER")
        local shine = f:CreateTexture(nil, "BORDER")     -- faint light along the top edge
        shine:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
        shine:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -1)
        shine:SetHeight(1)
        shine:SetColorTexture(1, 1, 1, 0.05)
    end
    local card = { frame = f, rows = {}, title = title, desc = desc,
        pinned = (type(opts) == "table" and opts.pinned) and true or false,
        openFirst = (type(opts) == "table" and opts.open) and true or false }
    if title and UI.sharp then
        -- a header bar: the section name in the highlight colour, its description after it in
        -- grey, a line under the bar, and a button on the right that folds the section away
        local bar = f:CreateTexture(nil, "BACKGROUND", nil, 1)
        bar:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
        bar:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -1)
        bar:SetHeight(SHARP_BAR_H - 1)
        bar:SetColorTexture(1, 1, 1, 0.045)
        local under = f:CreateTexture(nil, "BORDER")
        under:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -SHARP_BAR_H)
        under:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -SHARP_BAR_H)
        under:SetHeight(1)
        UI.Accent(under, 0.35)
        local fs = UI.Text(f, title, 1)
        fs:SetPoint("LEFT", f, "TOPLEFT", 14, -SHARP_BAR_H / 2)
        fs:SetWordWrap(false)
        local a = W().accent
        fs:SetTextColor(a[1], a[2], a[3])
        UI._sectionTitles = UI._sectionTitles or {}
        table.insert(UI._sectionTitles, fs)
        card.titleText = fs
        local fold = CreateFrame("Button", nil, f)
        fold:SetSize(SHARP_BAR_H, SHARP_BAR_H)
        fold:SetPoint("TOPRIGHT", f, "TOPRIGHT", -4, 0)
        local foldTx = UI.Text(fold, "-", 2, 0.62, 0.62, 0.67)
        foldTx:SetPoint("CENTER", 0, 1)
        local foldHl = fold:CreateTexture(nil, "HIGHLIGHT")
        foldHl:SetAllPoints()
        foldHl:SetColorTexture(1, 1, 1, 0.06)
        card.fold, card.foldText = fold, foldTx
        if type(desc) == "string" and desc ~= "" then
            local d = UI.Text(f, desc, -2, 0.62, 0.62, 0.67)
            d:SetPoint("LEFT", fs, "RIGHT", 10, 0)
            d:SetPoint("RIGHT", fold, "LEFT", -6, 0)
            d:SetWordWrap(false)
            card.descText = d
        end
    elseif title then
        local dot = UI.Round(f, "ARTWORK", 7)
        dot:SetPoint("TOPLEFT", f, "TOPLEFT", 16, -17)
        UI.Accent(dot, 1)
        local fs = UI.Text(f, title, UI.classic and 4 or 2, 1, 1, 1)
        fs:SetPoint("LEFT", dot, "RIGHT", 9, 0)
        card.titleText = fs
        if UI.classic then
            -- Blizzard-style divider under the title
            local div = f:CreateTexture(nil, "ARTWORK")
            div:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -26)
            div:SetPoint("TOPRIGHT", f, "TOPRIGHT", -10, -26)
            div:SetHeight(8)
            if not Art(div, "Interface\\Common\\UI-TooltipDivider-Transparent", GOLD[1], GOLD[2], GOLD[3], 0.25) then
                div:SetHeight(1)
            end
        end
        if type(desc) == "string" and desc ~= "" then
            local d = UI.Text(f, desc, -1, 0.62, 0.62, 0.67)
            d:SetPoint("TOPLEFT", f, "TOPLEFT", 32, UI.classic and -36 or -32)
            d:SetPoint("RIGHT", f, "RIGHT", -16, 0)
            d:SetWordWrap(false)
            card.descText = d
        end
    end
    table.insert(self.cards, card)
    self.current = card
    return card
end
Page.Header = Page.Section   -- older modules call Header()

----------------------------------------------------------------------
-- Undo: every change made with a switch, slider, dropdown or colour is remembered (with the
-- value it had before), newest first. Dragging a slider counts as one change. The Undo button
-- at the bottom of the window puts the last one back.
----------------------------------------------------------------------
local undoStack = {}
local UNDO_MAX = 100
local UNDO_MERGE = 1.5          -- changes to the same control this close together count as one
UI._undoStack = undoStack

local function CopyColor(c)
    if type(c) ~= "table" then return c end
    return { c[1], c[2], c[3], c[4] }
end

-- Wraps a setter: remembers what get() returned before the change.
local function Undoable(label, get, set, isColor)
    local token = {}
    return function(...)
        local now = GetTime and GetTime() or 0
        local top = undoStack[#undoStack]
        if not (top and top.token == token and now - top.at <= UNDO_MERGE) then
            local okG, old = pcall(get)
            if okG then
                if isColor then old = CopyColor(old) end
                undoStack[#undoStack + 1] = { token = token, label = label, old = old, set = set, color = isColor, at = now }
                if #undoStack > UNDO_MAX then table.remove(undoStack, 1) end
            end
        elseif top then
            top.at = now
        end
        local r = set(...)
        if UI.UpdateUndo then UI.UpdateUndo() end
        return r
    end
end

UI._Undoable = function(...) return Undoable(...) end

function UI.Undo()
    local e = table.remove(undoStack)
    if not e then return false end
    local ok, err
    if e.color and type(e.old) == "table" then
        ok, err = pcall(e.set, e.old[1], e.old[2], e.old[3], e.old[4])
    else
        ok, err = pcall(e.set, e.old)
    end
    if not ok then NS.ReportError("undo " .. tostring(e.label), err) end
    if UI.RefreshAll then UI.RefreshAll() end
    if UI.UpdateUndo then UI.UpdateUndo() end
    return true, e.label
end

----------------------------------------------------------------------
-- Test buttons: a module's "Test" button doesn't sit in its tab any more. It is listed in the
-- Test menu at the bottom left of the window, so any feature can be tried from any tab.
----------------------------------------------------------------------
UI.tests = {}
local function IsTestLabel(label)
    local l = tostring(label or ""):lower()
    return l:find("^test") ~= nil or l:find("^show test") ~= nil
end

local function AddRow(self, height, label, half)
    local card = self.current or self:Section(nil)
    local f = CreateFrame("Frame", nil, card.frame)
    if type(height) == "number" then height = RowH(height) end
    local row = {
        frame = f, label = type(label) == "string" and label or nil, half = half and true or false,
        height = (type(height) == "function") and height or function() return height end,
    }
    table.insert(card.rows, row)
    if UI.sharp and half then
        -- soft highlight while the mouse is over the row (kept while over its controls)
        local hov = f:CreateTexture(nil, "BACKGROUND")
        hov:SetPoint("TOPLEFT", f, "TOPLEFT", -6, 1)
        hov:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 6, -1)
        hov:SetColorTexture(1, 1, 1, 0.035)
        hov:Hide()
        f:EnableMouse(true)
        if f.SetMouseClickEnabled then pcall(f.SetMouseClickEnabled, f, false) end
        local function watch()
            local ok, over = pcall(f.IsMouseOver, f)
            if not (ok and over) then hov:Hide(); f:SetScript("OnUpdate", nil) end
        end
        f:SetScript("OnEnter", function() hov:Show(); f:SetScript("OnUpdate", watch) end)
        row.hover = hov
    end
    return f, row
end

function Page:Note(text)
    local f, row = AddRow(self, 14)
    row.note = type(text) == "string" and text or nil          -- searchable, but ranks below real settings
    local fs = UI.Text(f, text, -1, 0.62, 0.62, 0.67)
    fs:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
    fs:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
    fs:SetJustifyV("TOP")
    fs:SetWordWrap(true)
    row.height = function(w)
        if w and w > 20 then fs:SetWidth(w) end
        local h = fs:GetStringHeight()
        if not h or h < 12 then h = 14 end
        return h + 2
    end
    self:Reflow()
    return fs
end

function Page:Check(label, get, set, desc)
    set = Undoable(label, get, set)
    local f, row = AddRow(self, 24, label, true)
    local sw = Toggle(f, get, set)
    row.kind, row.ctrl, row.get, row.set = "check", sw, get, set
    local fs = UI.Text(f, label, LabelOff())
    if UI.classic then
        sw:SetPoint("LEFT", f, "LEFT", -4, 0)
        fs:SetPoint("LEFT", sw, "RIGHT", 2, 1)
        fs:SetPoint("RIGHT", f, "RIGHT", 0, 0)
    else
        sw:SetPoint("RIGHT", f, "RIGHT", 0, 0)
        fs:SetPoint("LEFT", f, "LEFT", 0, 0)
        fs:SetPoint("RIGHT", sw, "LEFT", -12, 0)
    end
    fs:SetWordWrap(false)
    LabelTip(f, fs, label)
    if type(desc) == "string" then Tip(sw, label, desc) end
    row.fs = fs
    table.insert(self.refreshers, sw.Refresh)
    self:Reflow()
    return sw
end

-- The number on the right of a slider is a small text box: click it, type a value and press
-- Enter (Escape or clicking away puts the old value back). Typed values are kept inside the
-- slider's range and rounded to its step.
local function ParseNumber(text)
    if type(text) ~= "string" then return nil end
    text = text:gsub(",", "."):gsub("[^%d%.%-]", "")
    return tonumber(text)
end

function Page:Slider(label, min, max, step, get, set, fmt)
    set = Undoable(label, get, set)
    local f, row = AddRow(self, 24, label, true)
    row.kind = "slider"
    local holder = CreateFrame("Frame", nil, f)
    holder:SetPoint("RIGHT", f, "RIGHT", 0, 0)
    holder:SetSize(UI.sharp and 54 or 58, UI.sharp and 18 or 20)
    local edge = holder:CreateTexture(nil, "BACKGROUND")
    edge:SetAllPoints()
    edge:SetColorTexture(1, 1, 1, 0.10)
    local inner = holder:CreateTexture(nil, "BORDER")
    inner:SetPoint("TOPLEFT", 1, -1)
    inner:SetPoint("BOTTOMRIGHT", -1, 1)
    inner:SetColorTexture(0.05, 0.05, 0.06, 1)

    local val = CreateFrame("EditBox", nil, holder)
    val:SetPoint("TOPLEFT", holder, "TOPLEFT", 4, -1)
    val:SetPoint("BOTTOMRIGHT", holder, "BOTTOMRIGHT", -4, 1)
    val:SetAutoFocus(false)
    val:SetMaxLetters(12)
    val:SetJustifyH("CENTER")
    SetFontSafe(val, (NS.db and W().fontSize or 12))
    texts[val] = 0
    roles[val] = "body"
    local tc = (NS.db and W().text) or { 0.90, 0.90, 0.92 }
    val:SetTextColor(tc[1], tc[2], tc[3])
    Tip(val, label, string.format("Click and type a value, then press Enter (%s to %s).",
        fmt and fmt(min) or tostring(min), fmt and fmt(max) or tostring(max)))

    local s = UI.classic and BackdropFrame("Slider", f) or CreateFrame("Slider", nil, f)
    s:SetPoint("RIGHT", holder, "LEFT", -10, 0)
    s:SetSize(UI.sharp and 104 or 180, UI.classic and 17 or 18)
    s:SetOrientation("HORIZONTAL")
    s:SetMinMaxValues(min, max)
    s:SetValueStep(step)
    if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end

    local track = s:CreateTexture(nil, "BACKGROUND")
    track:SetPoint("LEFT", s, "LEFT", 0, 0)
    track:SetPoint("RIGHT", s, "RIGHT", 0, 0)
    track:SetHeight(4)
    track:SetColorTexture(1, 1, 1, 0.10)

    local classicBar = UI.classic and SetBackdrop(s, {
        bgFile = "Interface\\Buttons\\UI-SliderBar-Background",
        edgeFile = "Interface\\Buttons\\UI-SliderBar-Border",
        tile = true, tileSize = 8, edgeSize = 8,
        insets = { left = 3, right = 3, top = 6, bottom = 6 },
    })
    local thumb
    if classicBar then
        track:Hide()
        local okT = pcall(s.SetThumbTexture, s, "Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
        if not okT then s:SetThumbTexture(WHITE) end
        thumb = s:GetThumbTexture()
        thumb:SetSize(32, 32)
        if not okT then thumb:SetSize(10, 16); UI.Accent(thumb, 1) end
    else
        local thumbOK = pcall(s.SetThumbTexture, s, ROUND)
        if not thumbOK then s:SetThumbTexture(WHITE) end
        thumb = s:GetThumbTexture()
        if thumbOK then rounds[thumb] = true end
        thumb:SetSize(14, 14)
        UI.Accent(thumb, 1)
        local fill = s:CreateTexture(nil, "ARTWORK")
        fill:SetHeight(4)
        fill:SetPoint("LEFT", track, "LEFT", 0, 0)
        fill:SetPoint("RIGHT", thumb, "CENTER", 0, 0)
        UI.Accent(fill, 0.6)
    end

    local fs = UI.Text(f, label, LabelOff())
    fs:SetPoint("LEFT", f, "LEFT", 0, 0)
    fs:SetPoint("RIGHT", s, "LEFT", -12, 0)
    fs:SetWordWrap(false)
    LabelTip(f, fs, label)
    row.ctrl, row.fs = s, fs

    local refreshing = false
    local function show(v) val:SetText(fmt and fmt(v) or tostring(v)) end
    local function snap(v)
        v = math.floor(v / step + 0.5) * step
        return tonumber(string.format("%.4f", v))
    end
    s:SetScript("OnValueChanged", function(_, v)
        if refreshing then return end
        v = snap(v)
        show(v)
        set(v)
    end)
    local function refresh()
        refreshing = true
        local v = get() or min
        s:SetValue(v)
        if not val:HasFocus() then show(v) end
        refreshing = false
    end

    local function commit()
        local v = ParseNumber(val:GetText())
        if v then
            v = snap(math.max(min, math.min(max, v)))
            refreshing = true
            s:SetValue(v)
            refreshing = false
            set(v)
            show(v)
        else
            show(get() or min)
        end
        val:ClearFocus()
    end
    val:SetScript("OnEnterPressed", commit)
    val:SetScript("OnEscapePressed", function() show(get() or min); val:ClearFocus() end)
    val:SetScript("OnEditFocusGained", function()
        local a = W().accent
        edge:SetColorTexture(a[1], a[2], a[3], 1)
        val:HighlightText()
    end)
    val:SetScript("OnEditFocusLost", function()
        edge:SetColorTexture(1, 1, 1, 0.10)
        val:HighlightText(0, 0)
        show(get() or min)
    end)
    table.insert(self.refreshers, refresh)
    refresh()
    self:Reflow()
    return s
end

function Page:Color(label, get, set)
    set = Undoable(label, get, set, true)
    local f, row = AddRow(self, 24, label, true)
    local btn = CreateFrame("Button", nil, f)
    btn:SetSize(40, 18)
    row.kind, row.ctrl, row.get, row.set = "color", btn, get, set
    btn:SetPoint("RIGHT", f, "RIGHT", 0, 0)
    local edge = btn:CreateTexture(nil, "BACKGROUND")
    edge:SetAllPoints()
    edge:SetColorTexture(1, 1, 1, 0.25)
    local swatch = btn:CreateTexture(nil, "ARTWORK")
    swatch:SetPoint("TOPLEFT", 1, -1)
    swatch:SetPoint("BOTTOMRIGHT", -1, 1)
    local hl = btn:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.12)

    local fs = UI.Text(f, label, LabelOff())
    fs:SetPoint("LEFT", f, "LEFT", 0, 0)
    fs:SetPoint("RIGHT", btn, "LEFT", -12, 0)
    fs:SetWordWrap(false)
    LabelTip(f, fs, label)
    row.fs = fs

    local function refresh()
        local c = get()
        swatch:SetColorTexture(c[1], c[2], c[3], 1)
    end
    btn:SetScript("OnClick", function()
        local c = get()
        UI.PickColor(c[1], c[2], c[3], c[4] or 1, function(r, g, b, a)
            set(r, g, b, a)
            refresh()
        end)
    end)
    table.insert(self.refreshers, refresh)
    refresh()
    self:Reflow()
    return btn
end

-- One shared drop-down list: opens under a box, one row per option, closes on pick,
-- on a second click, or when the mouse leaves it for a moment.
local dropList, dropOwner
local function DropList()
    if dropList then return dropList end
    local l = BackdropFrame("Frame", UIParent)
    l:SetFrameStrata("FULLSCREEN_DIALOG")
    l:SetClampedToScreen(true)
    l:EnableMouse(true)
    l:Hide()
    if not SetBackdrop(l, {
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 14,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    }) then
        local bg = l:CreateTexture(nil, "BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(0.06, 0.06, 0.07, 0.97)
        Edges(l, 1, 1, 1, 0.15)
    elseif l.SetBackdropColor then
        pcall(l.SetBackdropColor, l, 0.04, 0.04, 0.05, 0.96)
    end
    l.rows = {}
    local away = 0
    l:SetScript("OnUpdate", function(self, dt)
        if self:IsMouseOver() or (dropOwner and dropOwner:IsMouseOver()) then away = 0; return end
        away = away + (dt or 0)
        if away > 1.2 then self:Hide() end
    end)
    l:SetScript("OnHide", function() dropOwner = nil; away = 0 end)
    dropList = l
    return l
end

local function OpenDropList(owner, options, cur, onPick)
    local l = DropList()
    if l:IsShown() and dropOwner == owner then l:Hide(); return end
    dropOwner = owner
    local ROW = 20
    for i, o in ipairs(options) do
        local r = l.rows[i]
        if not r then
            r = CreateFrame("Button", nil, l)
            r:SetHeight(ROW)
            local hl = r:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            UI.Accent(hl, 0.25)
            r.mark = r:CreateTexture(nil, "ARTWORK")
            r.mark:SetSize(5, 5)
            r.mark:SetPoint("LEFT", r, "LEFT", 8, 0)
            UI.Accent(r.mark, 1)
            r.text = UI.Text(r, "", -1)
            r.text:SetPoint("LEFT", r, "LEFT", 20, 0)
            r.text:SetPoint("RIGHT", r, "RIGHT", -8, 0)
            r.text:SetWordWrap(false)
            l.rows[i] = r
        end
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", l, "TOPLEFT", 4, -4 - (i - 1) * ROW)
        r:SetPoint("TOPRIGHT", l, "TOPRIGHT", -4, -4 - (i - 1) * ROW)
        r.text:SetText(o[2])
        r.mark:SetShown(o[1] == cur)
        r:SetScript("OnClick", function() l:Hide(); onPick(o[1]) end)
        r:Show()
    end
    for i = #options + 1, #l.rows do l.rows[i]:Hide() end
    l:SetScale(owner:GetEffectiveScale() / UIParent:GetEffectiveScale())
    l:SetWidth(math.max(160, owner:GetWidth()))
    l:SetHeight(#options * ROW + 8)
    l:ClearAllPoints()
    l:SetPoint("TOPLEFT", owner, "BOTTOMLEFT", 0, -2)
    l:Show()
end

-- The box that opens the list: looks like a game drop-down in the classic style.
local function MakeDropBox(parent, width, height)
    if not UI.classic then
        local b = UI.MakeButton(parent, "", width, height)
        local arrow = UI.Text(b, "v", -2, 0.62, 0.62, 0.67)
        arrow:SetPoint("RIGHT", b, "RIGHT", -8, 0)
        b.label:ClearAllPoints()
        b.label:SetPoint("LEFT", b, "LEFT", 10, 0)
        b.label:SetPoint("RIGHT", arrow, "LEFT", -6, 0)
        b.label:SetJustifyH("LEFT")
        b.label:SetWordWrap(false)
        return b
    end
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, height)
    local edge = b:CreateTexture(nil, "BACKGROUND")
    edge:SetAllPoints()
    edge:SetColorTexture(0.42, 0.42, 0.45, 1)
    local fill = b:CreateTexture(nil, "BORDER")
    fill:SetPoint("TOPLEFT", 1, -1)
    fill:SetPoint("BOTTOMRIGHT", -1, 1)
    fill:SetColorTexture(0.02, 0.02, 0.03, 0.92)
    local arrow = b:CreateTexture(nil, "ARTWORK")
    arrow:SetSize(height - 2, height - 2)
    arrow:SetPoint("RIGHT", b, "RIGHT", -1, 0)
    if not Art(arrow, "Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up", GOLD[1], GOLD[2], GOLD[3], 0.8) then
        arrow:SetSize(8, 8)
    end
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetPoint("TOPLEFT", 1, -1)
    hl:SetPoint("BOTTOMRIGHT", -1, 1)
    hl:SetColorTexture(1, 1, 1, 0.06)
    local fs = UI.Text(b, "", -1, 1, 1, 1)
    fs:SetPoint("LEFT", b, "LEFT", 8, 0)
    fs:SetPoint("RIGHT", arrow, "LEFT", -2, 0)
    fs:SetWordWrap(false)
    b.label = fs
    return b
end

-- options = { { "key", "Label" }, ... }
function Page:Cycle(label, options, get, set)
    set = Undoable(label, get, set)
    local f, row = AddRow(self, 26, label, true)
    local btn = MakeDropBox(f, UI.sharp and 128 or 190, UI.sharp and 20 or 22)
    btn:SetPoint("RIGHT", f, "RIGHT", 0, 0)
    local fs = UI.Text(f, label, LabelOff())
    fs:SetPoint("LEFT", f, "LEFT", 0, 0)
    fs:SetPoint("RIGHT", btn, "LEFT", -12, 0)
    fs:SetWordWrap(false)
    LabelTip(f, fs, label)
    row.kind, row.ctrl, row.fs = "cycle", btn, fs

    local function refresh()
        local cur = get()
        for _, o in ipairs(options) do
            if o[1] == cur then btn.label:SetText(o[2]); return end
        end
        btn.label:SetText(tostring(cur))
    end
    btn:SetScript("OnClick", function()
        OpenDropList(btn, options, get(), function(v)
            set(v)
            refresh()
        end)
    end)
    table.insert(self.refreshers, refresh)
    refresh()
    self:Reflow()
    return btn
end

function Page:Button(label, onClick, width)
    if IsTestLabel(label) and self.moduleName then
        -- listed in the Test menu at the bottom of the window instead of in the tab
        local what = tostring(label):gsub("^[Ss]how test icons", "test icons"):gsub("^[Tt]est%s*", "")
        UI.tests[#UI.tests + 1] = { key = self.moduleKey, name = self.moduleName, label = what, run = onClick }
        local dummy = CreateFrame("Button")
        dummy:Hide()
        return dummy
    end
    local f = AddRow(self, 28, label)
    local b = UI.MakeButton(f, label, width or 220, 24)
    b:SetPoint("LEFT", f, "LEFT", 0, 0)
    b:SetScript("OnClick", onClick)
    self:Reflow()
    return b
end

local function Trim(s)
    s = tostring(s or ""):gsub("^%s+", "")
    s = s:gsub("%s+$", "")
    return s
end

-- A text box with an Add button on one row. onSubmit(text) runs on Enter or on the
-- button; the box is cleared afterwards unless onSubmit returns false.
function Page:Input(placeholder, onSubmit, buttonText)
    local f = AddRow(self, 28, placeholder)
    local btn = UI.MakeButton(f, buttonText or "Add", 72, 24)
    btn:SetPoint("RIGHT", f, "RIGHT", 0, 0)

    local holder = CreateFrame("Frame", nil, f)
    holder:SetPoint("LEFT", f, "LEFT", 0, 0)
    holder:SetPoint("RIGHT", btn, "LEFT", -8, 0)
    holder:SetHeight(24)
    local edge = holder:CreateTexture(nil, "BACKGROUND")
    edge:SetAllPoints()
    edge:SetColorTexture(1, 1, 1, 0.10)
    local fill = holder:CreateTexture(nil, "BORDER")
    fill:SetPoint("TOPLEFT", 1, -1)
    fill:SetPoint("BOTTOMRIGHT", -1, 1)
    fill:SetColorTexture(0.05, 0.05, 0.06, 1)

    local box = CreateFrame("EditBox", nil, holder)
    box:SetPoint("TOPLEFT", holder, "TOPLEFT", 7, -2)
    box:SetPoint("BOTTOMRIGHT", holder, "BOTTOMRIGHT", -7, 2)
    box:SetAutoFocus(false)
    box:SetMaxLetters(80)
    SetFontSafe(box, (NS.db and W().fontSize or 12))
    texts[box] = 0
    roles[box] = "body"
    local c = (NS.db and W().text) or { 0.90, 0.90, 0.92 }
    box:SetTextColor(c[1], c[2], c[3])

    local hint = UI.Text(holder, placeholder or "", -1, 0.62, 0.62, 0.67)
    hint:SetPoint("LEFT", holder, "LEFT", 8, 0)
    hint:SetPoint("RIGHT", holder, "RIGHT", -8, 0)
    hint:SetWordWrap(false)

    local function showHint()
        hint:SetShown((box:GetText() or "") == "" and not box:HasFocus())
    end
    local function submit()
        local text = Trim(box:GetText())
        if text == "" then box:ClearFocus(); return end
        local keep = onSubmit(text)
        if keep ~= false then box:SetText("") end
        box:ClearFocus()
        showHint()
    end
    box:SetScript("OnEnterPressed", submit)
    box:SetScript("OnEscapePressed", function() box:ClearFocus() end)
    box:SetScript("OnTextChanged", showHint)
    box:SetScript("OnEditFocusGained", function()
        local a = W().accent
        edge:SetColorTexture(a[1], a[2], a[3], 1)
        showHint()
    end)
    box:SetScript("OnEditFocusLost", function()
        edge:SetColorTexture(1, 1, 1, 0.10)
        showHint()
    end)
    btn:SetScript("OnClick", submit)
    showHint()
    self:Reflow()
    return box, btn
end

-- A free-form area (used by the trainer list). The owner calls
-- container:SetContentHeight(h) whenever its content changes size.
function Page:Container()
    local f, row = AddRow(self, 10)
    local page = self
    f.contentHeight = 10
    row.height = function() return f.contentHeight end
    function f:SetContentHeight(h)
        self.contentHeight = math.max(1, h)
        page:Reflow()
    end
    self:Reflow()
    return f
end

-- Sharp style: the on/off button on each module in the side menu, drawn as a power symbol
-- (a ring with a gap at the top and a short bar through it). Its inner parts take the side menu's
-- colour so the ring reads as a ring.
local function SideColor()
    local w = W()
    local a = w.sidebar[4] or 0
    return w.bg[1] * (1 - a) + w.sidebar[1] * a, w.bg[2] * (1 - a) + w.sidebar[2] * a,
        w.bg[3] * (1 - a) + w.sidebar[3] * a
end
function UI.MakePower(parent, key, name)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(18, 18)
    local ring = UI.Round(b, "ARTWORK", 12)
    ring:SetPoint("CENTER", b, "CENTER", 0, 0)
    local hole = UI.Round(b, "ARTWORK", 8)
    hole:SetDrawLayer("ARTWORK", 2)
    hole:SetPoint("CENTER", ring, "CENTER", 0, 0)
    local gap = b:CreateTexture(nil, "ARTWORK", nil, 3)
    gap:SetSize(4, 5)
    gap:SetPoint("TOP", ring, "TOP", 0, 1)
    local bar = b:CreateTexture(nil, "ARTWORK", nil, 4)
    bar:SetSize(2, 7)
    bar:SetPoint("TOP", ring, "TOP", 0, 1)
    local hl = UI.Round(b, "HIGHLIGHT", 18)
    hl:SetPoint("CENTER")
    Paint(hl, 1, 1, 1, 0.08)
    function b.Refresh()
        local on = NS.Mod(key) and NS.Mod(key).enabled
        local r, g, bl = 0.40, 0.40, 0.44
        if on then local c = W().accent; r, g, bl = c[1], c[2], c[3] end
        Paint(ring, r, g, bl, 1)
        bar:SetColorTexture(r, g, bl, 1)
        local sr, sg, sb
        if b.behind then sr, sg, sb = b.behind() end
        if not sr then sr, sg, sb = SideColor() end
        Paint(hole, sr, sg, sb, 1)
        gap:SetColorTexture(sr, sg, sb, 1)
        b.on = on and true or false
    end
    b:SetScript("OnClick", function()
        local m = NS.Mod(key)
        if not m then return end
        m.enabled = not m.enabled
        NS.ApplyModule(key)
        UI.RefreshAll()
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        local on = NS.Mod(key) and NS.Mod(key).enabled
        GameTooltip:SetText(name or key, 1, 1, 1)
        GameTooltip:AddLine(on and "On - click to turn off" or "Off - click to turn on", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b.Refresh()
    return b
end

-- Sharp style (2.23.0): a rounded "pill" shape for the side menu buttons, built from the round
-- image cut in half for the two ends plus a flat middle, so nothing overlaps (no doubled alpha).
-- inset pulls it in from the button's edges; h is the button's height.
local function MakePill(parent, layer, sub, inset, h)
    local half = math.max(1, (h - 2 * inset) / 2)
    local L = UI.Round(parent, layer)
    L:SetDrawLayer(layer, sub)
    L:SetPoint("TOPLEFT", parent, "TOPLEFT", inset, -inset)
    L:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT", inset, inset)
    L:SetWidth(half)
    pcall(L.SetTexCoord, L, 0, 0.5, 0, 1)
    local R = UI.Round(parent, layer)
    R:SetDrawLayer(layer, sub)
    R:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -inset, -inset)
    R:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -inset, inset)
    R:SetWidth(half)
    pcall(R.SetTexCoord, R, 0.5, 1, 0, 1)
    local M = parent:CreateTexture(nil, layer, nil, sub)
    M:SetPoint("TOPLEFT", L, "TOPRIGHT", 0, 0)
    M:SetPoint("BOTTOMRIGHT", R, "BOTTOMLEFT", 0, 0)
    local pill = { L = L, M = M, R = R }
    function pill.SetColor(r, g, b, a)
        Paint(L, r, g, b, a); Paint(R, r, g, b, a)
        M:SetColorTexture(r, g, b, a or 1)
    end
    return pill
end
UI.MakePill = MakePill

-- Mix two colours: f = 0 gives the first, 1 the second.
local function Mix(r1, g1, b1, r2, g2, b2, f)
    return r1 + (r2 - r1) * f, g1 + (g2 - g1) * f, b1 + (b2 - b1) * f
end

-- Side menu order: groups in a fixed order, modules A-Z inside each group.
local GROUP_ORDER = { Style = 1, Combat = 2, Tools = 3, QoL = 4 }
local GROUP_LABEL = { Style = "LOOK", Combat = "COMBAT", Tools = "TOOLS", QoL = "QUALITY OF LIFE" }
local function SortedModules()
    local list = {}
    for i, key in ipairs(NS.moduleOrder) do list[#list + 1] = { key = key, i = i } end
    table.sort(list, function(a, b)
        local ma, mb = NS.modules[a.key], NS.modules[b.key]
        local ga, gb = GROUP_ORDER[ma.group or ""] or 9, GROUP_ORDER[mb.group or ""] or 9
        if ga ~= gb then return ga < gb end
        local na, nb = string.lower(ma.name or a.key), string.lower(mb.name or b.key)
        if na ~= nb then return na < nb end
        return a.i < b.i
    end)
    for i, e in ipairs(list) do list[i] = e.key end
    return list
end
UI.SortedModules = SortedModules

----------------------------------------------------------------------
-- Window-wide refresh
----------------------------------------------------------------------
local function RefreshTabDots()
    for _, t in ipairs(tabList) do
        if t.module and UI.sharp then
            local on = NS.Mod(t.key) and NS.Mod(t.key).enabled
            if t.power then t.power.Refresh() end
            if t.labelFs then
                local c = on and W().text or W().muted
                if t.pill and t.key == currentTab then c = { 1, 1, 1 } end
                t.labelFs:SetTextColor(c[1], c[2], c[3])
                t.labelFs:SetAlpha((on or (t.pill and t.key == currentTab)) and 1 or 0.7)
            end
            if t.PaintPill then t.PaintPill() end
        elseif t.module then
            local on = NS.Mod(t.key) and NS.Mod(t.key).enabled
            if on and t.dot then
                local c = W().accent
                Paint(t.dot, c[1], c[2], c[3], 1)
            elseif t.dot then
                Paint(t.dot, 0.32, 0.32, 0.35, 1)
            end
        end
    end
end

function UI.RefreshAll()
    for _, t in ipairs(tabList) do
        if t.PaintPill and not t.module then t.PaintPill() end
    end
    for _, p in ipairs(pages) do
        for _, fn in ipairs(p.refreshers) do fn() end
    end
    for _, t in ipairs(tabList) do
        if t.switch then t.switch.Refresh() end
    end
    RefreshTabDots()
end

function UI.ApplyStyle()
    if not win then return end
    local w = W()
    win:SetScale(w.scale)
    bgTex:SetColorTexture(w.bg[1], w.bg[2], w.bg[3], w.bg[4])
    if UI.classic and UI._deco then
        local bd = CLASSIC_BORDERS[w.classicBorder or "stone"] or CLASSIC_BORDERS.stone
        local back = CLASSIC_BACKS[w.classicBack or "dark"] or CLASSIC_BACKS.dark
        local deco = UI._deco
        deco:ClearAllPoints()
        deco:SetPoint("TOPLEFT", win, "TOPLEFT", -bd.out, bd.out)
        deco:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", bd.out, -bd.out)
        local ok = SetBackdrop(deco, {
            bgFile = back, edgeFile = bd.file, tile = true, tileSize = (back == WHITE) and 8 or 256,
            edgeSize = bd.size, insets = { left = bd.inset, right = bd.inset, top = bd.inset, bottom = bd.inset },
        })
        if ok and deco.SetBackdropColor then
            if back == WHITE then
                pcall(deco.SetBackdropColor, deco, w.bg[1], w.bg[2], w.bg[3], w.bg[4])
            else
                pcall(deco.SetBackdropColor, deco, 1, 1, 1, w.bg[4])
            end
            bgTex:SetColorTexture(0, 0, 0, 0)            -- the backdrop is the background now
        end
    end
    titleBG:SetColorTexture(w.titleBar[1], w.titleBar[2], w.titleBar[3], w.bg[4])
    sideBG:SetColorTexture(w.sidebar[1], w.sidebar[2], w.sidebar[3], w.sidebar[4])
    local bs = math.max(1, math.min(4, math.floor((w.borderSize or 1) + 0.5)))
    for _, e in ipairs(borderEdges) do
        e:SetColorTexture(w.border[1], w.border[2], w.border[3], UI.classic and 0 or w.border[4])
        if edgeVertical[e] then e:SetWidth(bs) else e:SetHeight(bs) end
    end
    RestyleAccents()
    RestyleTexts()
    -- title bar: title colour, version text, accent mark and line
    if UI._title then
        local tc = w.titleColorOn and w.titleColor or (UI.classic and GOLD) or { 1, 1, 1 }
        UI._title:SetTextColor(tc[1], tc[2], tc[3])
    end
    if UI._ver then UI._ver:SetShown(w.showVersion ~= false) end
    if UI.sharp and UI._logo then
        -- "Show the coloured mark before the title" shows or hides the logo in this style
        local show = w.titleMark ~= false
        for _, part in ipairs(UI._logoParts or {}) do part:SetShown(show) end
        UI._title:ClearAllPoints()
        if show then UI._title:SetPoint("LEFT", UI._logo, "RIGHT", 10, 0)
        else UI._title:SetPoint("LEFT", titleBar, "LEFT", 14, 0) end
    elseif UI._mark then
        UI._mark:SetShown(w.titleMark ~= false)
        UI._title:ClearAllPoints()
        if w.titleMark ~= false then UI._title:SetPoint("LEFT", UI._mark, "RIGHT", 8, 0)
        else UI._title:SetPoint("LEFT", titleBar, "LEFT", 12, 0) end
    end
    if UI._tline then UI._tline:SetShown(w.titleLine ~= false) end
    for _, u in ipairs(underlines) do u:SetShown(w.underlines ~= false) end
    if UI.sharp then
        local a = w.accent
        for _, g in ipairs(UI._groupLabels or {}) do g:SetTextColor(a[1], a[2], a[3]) end
        for _, t in ipairs(UI._sectionTitles or {}) do t:SetTextColor(a[1], a[2], a[3]) end
        if UI._logoHole then Paint(UI._logoHole, w.titleBar[1], w.titleBar[2], w.titleBar[3], 1) end
        for _, fn in ipairs(UI._sharpRestyle or {}) do pcall(fn) end
    end
    grip:SetShown(not w.locked)
    for _, p in ipairs(pages) do p:Reflow() end
    UI.RefreshAll()
end

local function SavePosition()
    local point, _, relPoint, x, y = win:GetPoint()
    if point then W().point = { point, relPoint, x, y } end
end

local function SaveSize()
    W().w, W().h = math.floor(win:GetWidth() + 0.5), math.floor(win:GetHeight() + 0.5)
end

----------------------------------------------------------------------
-- Tabs
----------------------------------------------------------------------
local function SelectTab(key)
    UI.ClosePops()
    currentTab = key
    for k, t in pairs(tabs) do
        local on = (k == key)
        t.expanded = on and t.page.menuMode and true or false     -- one dropdown open at a time
        t.page.frame:SetShown(on)
        t.header:SetShown(on)
        t.sel:SetShown(on)
        t.selBar:SetShown(on)
        if t.selGlow then t.selGlow:SetShown(on) end
        if t.preview then t.preview:SetShown(on) end
        if on then t.page:Reflow() end
        if on and t.header.LayoutTabs then pcall(t.header.LayoutTabs) end
    end
    if UI._resetBtn then
        local mod = tabs[key] and tabs[key].module
        pcall(UI._resetBtn.SetAlpha, UI._resetBtn, mod and 1 or 0.4)
        pcall(UI._resetBtn.SetEnabled, UI._resetBtn, mod and true or false)
    end
    if UI.LayoutSidebar then UI.LayoutSidebar(true) end
    RefreshTabDots()
    for _, t in pairs(tabs) do
        if t.PaintPill and not t.module then t.PaintPill() end
    end
end

-- Pinned header: title, description, and (for modules) the enable switch + reset.
-- Sharp style header: title, one line of description, the module's on/off switch, and (added once
-- the page is built) a row of tabs for its areas. Reset tab lives in the footer.
local SHARP_HEAD = 60
local SHARP_TAB_H = 26
local function BuildHeaderSharp(parent, title, desc, key)
    local h = CreateFrame("Frame", nil, parent)
    h:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 0)
    h:SetPoint("TOPRIGHT", parent, "TOPRIGHT", 0, 0)
    h:SetHeight(SHARP_HEAD)
    h:Hide()
    local sw
    if key then
        sw = Toggle(h, function() return NS.Mod(key).enabled end,
            function(v) NS.Mod(key).enabled = v; NS.ApplyModule(key) end)
        sw:SetPoint("TOPRIGHT", h, "TOPRIGHT", -18, -16)
        local lbl = UI.Text(h, "On", -2, 0.62, 0.62, 0.67)
        lbl:SetPoint("RIGHT", sw, "LEFT", -8, 0)
        local refreshSwitch = sw.Refresh
        function sw.Refresh()
            refreshSwitch()
            local on = NS.Mod(key) and NS.Mod(key).enabled
            lbl:SetText(on and "On" or "Off")
        end
    end
    local t = UI.Text(h, title, 6, 1, 1, 1)
    t:SetPoint("TOPLEFT", h, "TOPLEFT", 18, -14)
    t:SetPoint("RIGHT", h, "RIGHT", key and -110 or -18, 0)
    t:SetWordWrap(false)
    local d = UI.Text(h, desc or "", -2, 0.62, 0.62, 0.67)
    d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -5)
    d:SetPoint("RIGHT", h, "RIGHT", -18, 0)
    d:SetWordWrap(false)
    LabelTip(h, d, desc)
    local line = h:CreateTexture(nil, "ARTWORK")
    line:SetPoint("BOTTOMLEFT", h, "BOTTOMLEFT", 18, 0)
    line:SetPoint("BOTTOMRIGHT", h, "BOTTOMRIGHT", -18, 0)
    line:SetHeight(1)
    line:SetColorTexture(1, 1, 1, 0.07)
    h.tabs = {}

    -- One tab per area; tabs that don't fit wrap onto another line.
    function h.LayoutTabs()
        if #h.tabs == 0 then h:SetHeight(SHARP_HEAD); return end
        local width = h:GetWidth()
        if not width or width < 50 then width = 500 end
        local x, line = 18, 0
        for _, tb in ipairs(h.tabs) do
            local okW, sw2 = pcall(tb.fs.GetStringWidth, tb.fs)
            local w = math.max(44, math.floor(((okW and type(sw2) == "number") and sw2 or 60) + 22))
            if x > 18 and x + w > width - 18 then x, line = 18, line + 1 end
            tb:ClearAllPoints()
            tb:SetPoint("TOPLEFT", h, "TOPLEFT", x, -(SHARP_HEAD - 6 + line * SHARP_TAB_H))
            tb:SetSize(w, SHARP_TAB_H)
            tb.line = line
            x = x + w + 2
        end
        h.tabLines = line + 1
        h:SetHeight(SHARP_HEAD - 6 + (line + 1) * SHARP_TAB_H + 4)
    end
    function h.RefreshTabs(view)
        local a = W().accent
        for _, tb in ipairs(h.tabs) do
            local on = (tb.card == view)
            tb.under:SetShown(on)
            local c = on and { 1, 1, 1 } or W().muted
            tb.fs:SetTextColor(c[1], c[2], c[3])
            Paint(tb.under, a[1], a[2], a[3], 1)
        end
    end
    function h.AddTabs(page)
        for _, card in ipairs(page.areas or {}) do
            local tb = CreateFrame("Button", nil, h)
            tb.card = card
            tb.fs = UI.Text(tb, (card.title:gsub("%s*%b()", "")), -1)
            tb.fs:SetPoint("CENTER", tb, "CENTER", 0, 1)
            tb.fs:SetJustifyH("CENTER")
            tb.fs:SetWordWrap(false)
            local hl = tb:CreateTexture(nil, "HIGHLIGHT")
            hl:SetPoint("TOPLEFT", 1, -2); hl:SetPoint("BOTTOMRIGHT", -1, 2)
            hl:SetColorTexture(1, 1, 1, 0.05)
            tb.under = tb:CreateTexture(nil, "ARTWORK")
            tb.under:SetPoint("BOTTOMLEFT", tb, "BOTTOMLEFT", 6, 0)
            tb.under:SetPoint("BOTTOMRIGHT", tb, "BOTTOMRIGHT", -6, 0)
            tb.under:SetHeight(2)
            tb:SetScript("OnClick", function() page:Open(card) end)
            h.tabs[#h.tabs + 1] = tb
        end
        page.onOpen = function(card) h.RefreshTabs(card) end
        h:SetScript("OnSizeChanged", function() h.LayoutTabs() end)
        h.LayoutTabs()
        h.RefreshTabs(page.view)
        UI._sharpRestyle = UI._sharpRestyle or {}
        table.insert(UI._sharpRestyle, function() h.LayoutTabs(); h.RefreshTabs(page.view) end)
    end
    return h, sw
end
UI._BuildHeaderSharp = BuildHeaderSharp

local function BuildHeader(parent, title, desc, key)
    if UI.sharp then return BuildHeaderSharp(parent, title, desc, key) end
    local h = CreateFrame("Frame", nil, parent)
    h:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 0)
    h:SetPoint("TOPRIGHT", parent, "TOPRIGHT", 0, 0)
    h:SetHeight(HEADER_H)
    h:Hide()

    local right = 0
    local sw
    if key then
        sw = Toggle(h, function() return NS.Mod(key).enabled end,
            function(v) NS.Mod(key).enabled = v; NS.ApplyModule(key) end)
        sw:SetPoint("TOPRIGHT", h, "TOPRIGHT", -16, -18)
        local lbl = UI.Text(h, "Enabled", -1, 0.65, 0.65, 0.70)
        lbl:SetPoint("RIGHT", sw, "LEFT", -8, 0)
        local refreshSwitch = sw.Refresh
        function sw.Refresh()
            refreshSwitch()
            local on = NS.Mod(key) and NS.Mod(key).enabled
            lbl:SetText(on and "On" or "Off")
        end
        local reset = UI.MakeButton(h, "Reset tab", 84, 20)
        reset:SetPoint("TOPRIGHT", sw, "BOTTOMRIGHT", 0, -8)
        reset:SetScript("OnClick", function() NS.ResetModule(key) end)
        right = 130
    end

    local t = UI.Text(h, title, 8, 1, 1, 1)
    t:SetPoint("TOPLEFT", h, "TOPLEFT", 18, -16)
    local d = UI.Text(h, desc or "", -1, 0.62, 0.62, 0.67)
    d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -6)
    d:SetPoint("RIGHT", h, "RIGHT", -(right + 16), 0)
    d:SetJustifyV("TOP")
    d:SetWordWrap(true)
    if d.SetMaxLines then d:SetMaxLines(3) end

    local line = h:CreateTexture(nil, "ARTWORK")
    line:SetPoint("BOTTOMLEFT", h, "BOTTOMLEFT", 18, 0)
    line:SetPoint("BOTTOMRIGHT", h, "BOTTOMRIGHT", -18, 0)
    line:SetHeight(1)
    line:SetColorTexture(1, 1, 1, 0.06)
    local under = h:CreateTexture(nil, "ARTWORK", nil, 1)   -- short accent underline below the title area
    under:SetPoint("BOTTOMLEFT", h, "BOTTOMLEFT", 18, 0)
    under:SetSize(36, 2)
    UI.Accent(under, 1)
    underlines[#underlines + 1] = under
    return h, sw
end

----------------------------------------------------------------------
-- Window
----------------------------------------------------------------------
-- Theme presets. Picking one sets the window colors; any color can be changed afterwards.
-- Theme presets. Modern themes: { id, name, background, accent }. Classic themes use the
-- Blizzard-style window (stone or gold border, gold labels, checkboxes, red buttons) and also
-- pick a border and a background. Any color can be changed afterwards (it becomes Custom).
local THEMES = {
    { "blue",     "Modern: Aimbot Blue",  { 0.07, 0.07, 0.08 }, { 0.30, 0.70, 1.00 } },
    { "crimson",  "Modern: Crimson",      { 0.09, 0.06, 0.06 }, { 0.92, 0.27, 0.32 } },
    { "emerald",  "Modern: Emerald",      { 0.06, 0.085, 0.07 }, { 0.25, 0.85, 0.52 } },
    { "violet",   "Modern: Violet",       { 0.08, 0.06, 0.10 }, { 0.68, 0.42, 1.00 } },
    { "gold",     "Modern: Gold",         { 0.09, 0.08, 0.06 }, { 1.00, 0.78, 0.25 } },
    { "orange",   "Modern: Ember",        { 0.09, 0.07, 0.06 }, { 1.00, 0.52, 0.20 } },
    { "frost",    "Modern: Frost",        { 0.05, 0.07, 0.10 }, { 0.45, 0.88, 1.00 } },
    { "fel",      "Modern: Fel",          { 0.05, 0.07, 0.04 }, { 0.62, 1.00, 0.22 } },
    { "rose",     "Modern: Rose",         { 0.09, 0.06, 0.08 }, { 1.00, 0.45, 0.70 } },
    { "graphite", "Modern: Graphite",     { 0.12, 0.12, 0.13 }, { 0.78, 0.78, 0.84 } },
    { "black",    "Modern: Pure black",   { 0.00, 0.00, 0.00 }, { 0.30, 0.70, 1.00 } },
    { "midnight", "Modern: Midnight",     { 0.04, 0.05, 0.09 }, { 0.52, 0.56, 1.00 } },
    { "ocean",    "Modern: Ocean",        { 0.04, 0.08, 0.09 }, { 0.20, 0.82, 0.78 } },
    { "sand",     "Modern: Sand",         { 0.10, 0.09, 0.07 }, { 0.90, 0.72, 0.50 } },
    { "blood",    "Modern: Blood",        { 0.05, 0.02, 0.02 }, { 0.75, 0.08, 0.10 } },
    { "mono",     "Modern: Mono",         { 0.06, 0.06, 0.06 }, { 1.00, 1.00, 1.00 } },
    { "teal",     "Modern: Teal",         { 0.05, 0.075, 0.075 }, { 0.12, 0.82, 0.64 } },
    { "c_stone",  "Classic: Stone",       { 0, 0, 0 }, { 1.00, 0.82, 0.00 }, classic = true, border = "stone",   back = "dark" },
    { "c_gold",   "Classic: Gold trim",   { 0, 0, 0 }, { 1.00, 0.82, 0.00 }, classic = true, border = "gold",    back = "dark" },
    { "c_rock",   "Classic: Rock",        { 0, 0, 0 }, { 1.00, 0.82, 0.00 }, classic = true, border = "stone",   back = "rock" },
    { "c_marble", "Classic: Marble",      { 0, 0, 0 }, { 1.00, 0.82, 0.00 }, classic = true, border = "gold",    back = "marble" },
    { "c_tip",    "Classic: Tooltip",     { 0.03, 0.03, 0.05 }, { 1.00, 0.82, 0.00 }, classic = true, border = "tooltip", back = "plain" },
    { "c_horde",  "Classic: Horde",       { 0.10, 0.02, 0.02 }, { 1.00, 0.30, 0.20 }, classic = true, border = "stone", back = "plain" },
    { "c_ally",   "Classic: Alliance",    { 0.02, 0.04, 0.11 }, { 0.40, 0.65, 1.00 }, classic = true, border = "gold",  back = "plain" },
}


local function ApplyTheme(id)
    for _, t in ipairs(THEMES) do
        if t[1] == id then
            local w = W()
            local bg, ac = t[3], t[4]
            w.bg[1], w.bg[2], w.bg[3] = bg[1], bg[2], bg[3]
            w.border[1], w.border[2], w.border[3], w.border[4] = 0, 0, 0, 1
            w.accent[1], w.accent[2], w.accent[3] = ac[1], ac[2], ac[3]
            w.titleBar[1], w.titleBar[2], w.titleBar[3] = math.min(1, bg[1] + 0.05), math.min(1, bg[2] + 0.05), math.min(1, bg[3] + 0.05)
            w.sidebar[1], w.sidebar[2], w.sidebar[3], w.sidebar[4] = 0, 0, 0, 0.28
            w.text[1], w.text[2], w.text[3] = 0.90, 0.90, 0.92
            w.muted[1], w.muted[2], w.muted[3] = 0.62, 0.62, 0.67
            if t.classic then w.skin = "classic"
            elseif w.skin ~= "sharp" then w.skin = "modern" end      -- a colour theme keeps the Sharp layout
            if t.classic then
                -- gold labels, white titles, light grey notes, like the game's own option panels
                w.text[1], w.text[2], w.text[3] = 1.00, 0.82, 0.00
                w.muted[1], w.muted[2], w.muted[3] = 0.78, 0.78, 0.78
                w.titleBar[1], w.titleBar[2], w.titleBar[3] = 0, 0, 0
                w.sidebar[1], w.sidebar[2], w.sidebar[3], w.sidebar[4] = 0, 0, 0, 0.30
                w.classicBorder = t.border or "stone"
                w.classicBack = t.back or "dark"
            end
            w.theme = id
            return
        end
    end
end

UI._ApplyTheme = function(id) return ApplyTheme(id) end

local function BuildGeneral(page)
    local function Custom() W().theme = "custom"; UI.ApplyStyle() end
    local function ColorRow(label, key)
        page:Color(label,
            function() return W()[key] end,
            function(r, g, b) local c = W()[key]; c[1], c[2], c[3] = r, g, b; Custom() end)
    end

    page:Section("Theme", "Pick a ready-made look for this window")
    local options = { { "custom", "Custom" } }
    for _, t in ipairs(THEMES) do options[#options + 1] = { t[1], t[2] } end
    page:Cycle("Theme", options,
        function() return W().theme end,
        function(v) if v ~= "custom" then ApplyTheme(v) end; W().theme = v; UI.ApplyStyle() end)
    page:Cycle("Style", { { "classic", "Classic (game style)" }, { "modern", "Modern (flat)" },
            { "sharp", "Sharp (compact)" } },
        function() return W().skin end,
        function(v) W().skin = v; UI.RefreshAll() end)
    local styleNote = page:Note("")
    table.insert(page.refreshers, function()
        if W().skin ~= UI.builtSkin then
            styleNote:SetText("|cffff8040The style changes after a reload.|r Click \"Reload now\" below (or type /reload).")
        else
            styleNote:SetText("Classic uses the game's own look (stone or gold border, gold labels, checkboxes). "
                .. "Modern is flat with round switches. Sharp is compact: one long page per tab with a header bar on each "
                .. "section, settings in two columns and on/off buttons in the side menu. Changing any color makes the theme Custom.")
        end
    end)
    page:Cycle("Classic border", { { "stone", "Stone" }, { "gold", "Gold trim" }, { "tooltip", "Thin (tooltip)" }, { "none", "None" } },
        function() return W().classicBorder or "stone" end,
        function(v) W().classicBorder = v; UI.ApplyStyle() end)
    page:Cycle("Classic background", { { "dark", "Dark" }, { "rock", "Rock" }, { "marble", "Marble" }, { "plain", "Plain color" } },
        function() return W().classicBack or "dark" end,
        function(v) W().classicBack = v; UI.ApplyStyle() end)
    page:Button("Reload now", function() if ReloadUI then ReloadUI() end end, 160)

    page:Section("Look", "Font, outline, border and title bar details")
    local fontOpts = {}
    for _, f in ipairs(UI.FONTS) do fontOpts[#fontOpts + 1] = { f[1], f[2] } end
    page:Cycle("Font", fontOpts,
        function() return W().font or "default" end,
        function(v) W().font = v; UI.ApplyStyle() end)
    page:Cycle("Text outline", { { "none", "None" }, { "OUTLINE", "Thin" }, { "THICKOUTLINE", "Thick" } },
        function() return W().fontOutline or "none" end,
        function(v) W().fontOutline = v; UI.ApplyStyle() end)
    page:Check("Text shadow", function() return W().textShadow end,
        function(v) W().textShadow = v; UI.ApplyStyle() end)
    page:Slider("Border thickness (modern style)", 1, 4, 1,
        function() return W().borderSize or 1 end,
        function(v) W().borderSize = v; UI.ApplyStyle() end)
    page:Check("Show the version number in the title bar", function() return W().showVersion ~= false end,
        function(v) W().showVersion = v; UI.ApplyStyle() end)
    page:Check("Show the coloured mark before the title", function() return W().titleMark ~= false end,
        function(v) W().titleMark = v; UI.ApplyStyle() end)
    page:Check("Show the coloured line under the title bar", function() return W().titleLine ~= false end,
        function(v) W().titleLine = v; UI.ApplyStyle() end)
    page:Check("Show the coloured underline under each tab title", function() return W().underlines ~= false end,
        function(v) W().underlines = v; UI.ApplyStyle() end)

    page:Section("Window", "Size, opacity, text size and locking")
    page:Check("Show an \"Aimbot UI\" button on the Escape menu", function() return W().menuButton ~= false end,
        function(v) W().menuButton = v; UI.UpdateMenuButton() end)
    page:Slider("Window scale", 0.6, 1.6, 0.05,
        function() return W().scale end,
        function(v) W().scale = v; UI.ApplyStyle() end,
        function(v) return string.format("%.2f", v) end)
    page:Slider("Window opacity", 0.3, 1, 0.02,
        function() return W().bg[4] end,
        function(v) W().bg[4] = v; UI.ApplyStyle() end,
        function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)
    page:Slider("Side menu opacity", 0, 1, 0.02,
        function() return W().sidebar[4] end,
        function(v) W().sidebar[4] = v; UI.ApplyStyle() end,
        function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)
    page:Slider("Text size", 9, 18, 1,
        function() return W().fontSize end,
        function(v) W().fontSize = v; UI.ApplyStyle() end)
    page:Check("Lock window position and size",
        function() return W().locked end,
        function(v) W().locked = v; UI.ApplyStyle() end)
    page:Button("Reset window position and size", function()
        W().point = nil
        W().w, W().h = NS.WINDOW_DEFAULTS.w, NS.WINDOW_DEFAULTS.h
        win:ClearAllPoints()
        win:SetPoint("CENTER")
        win:SetSize(W().w, W().h)
    end, 260)

    page:Section("Colors", "Background, border, highlight and text colors")
    ColorRow("Window background", "bg")
    ColorRow("Title bar", "titleBar")
    ColorRow("Side menu", "sidebar")
    page:Color("Border",
        function() return W().border end,
        function(r, g, b) W().border[1], W().border[2], W().border[3] = r, g, b; Custom() end)
    page:Color("Highlight color (switches, sliders, selection)",
        function() return W().accent end,
        function(r, g, b) W().accent[1], W().accent[2], W().accent[3] = r, g, b; Custom() end)
    ColorRow("Text", "text")
    ColorRow("Small grey text (descriptions, notes)", "muted")
    page:Slider("Highlight strength", 0.2, 1, 0.05,
        function() return W().accent[4] or 1 end,
        function(v) W().accent[4] = v; UI.ApplyStyle() end,
        function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)
    page:Check("Use my own title colour", function() return W().titleColorOn end,
        function(v) W().titleColorOn = v; UI.ApplyStyle() end)
    page:Color("Title colour (\"AIMBOT UI\")",
        function() return W().titleColor end,
        function(r, g, b) local c = W().titleColor; c[1], c[2], c[3] = r, g, b; W().titleColorOn = true; UI.ApplyStyle() end)
    page:Button("Reset all window colors", function()
        local cur = W().theme
        if cur == "custom" or not cur then cur = UI.classic and "c_stone" or "blue" end
        ApplyTheme(cur); UI.ApplyStyle()
    end, 260)

    page:Section("Modules", "Switch whole modules on or off")
    for _, key in ipairs(SortedModules()) do
        local m = NS.modules[key]
        page:Check(m.name or key,
            function() return NS.Mod(key).enabled end,
            function(v) NS.Mod(key).enabled = v; NS.ApplyModule(key) end)
    end

    page:Section("Maintenance", "Reset everything or print diagnostics")
    StaticPopupDialogs["AIMBOTUI_RESET_ALL"] = {
        text = "Reset ALL Aimbot UI settings to defaults?",
        button1 = YES, button2 = NO,
        OnAccept = function() NS.ResetAll() end,
        timeout = 0, whileDead = true, hideOnEscape = true,
    }
    page:Button("Reset ALL settings to default", function()
        StaticPopup_Show("AIMBOTUI_RESET_ALL")
    end, 260)
    page:Button("Run diagnostics (opens a copy window)", function()
        if NS.Diagnose then NS.Diagnose() end
    end, 260)

    page:Section("Help", "Commands, controls and credits")
    page:Note("Drag the title bar to move the window and the bottom-right corner to resize it. "
        .. "Each tab opens a list of areas (in the Sharp style every section is on one long page instead; fold any section with its - button). "
        .. "In the Sharp style, the power button next to each module in the side menu turns it on or off. "
        .. "Every tab has its own Enabled switch and a Reset tab button.")
    page:Note("Commands:  /aimbot  opens the window.   /aimbot <tab>  opens a tab.   "
        .. "/aimbot <tab> on|off  toggles a module.   /sparkle  toggles Button Flash.   "
        .. "Tabs: lorti, damage, flash, mana, range, trainer, double, memory, mute, fps, privacy, dr, queue, plates, combat, kick, death, repair, talent, timers, loc, autoshot.")
    page:Note("Credits: Lorti UI Classic by Lorti, Chordsy, Macumba, Knall, Jozh, Xyz, Arrone and Redskin. "
        .. "NiceDamage by Montyburns. Their artwork and fonts are used here with the original credit.")
end


local function Create()
    local w = W()
    -- One time: switch to the classic (game-style) look introduced in 2.8.13.
    if w.styleV ~= 1 then
        w.styleV = 1
        ApplyTheme("c_stone")
    end
    UI.classic = (w.skin == "classic")
    UI.sharp = (w.skin == "sharp")
    UI.builtSkin = w.skin
    if UI.sharp then
        SIDEBAR_W = 206
        -- first time in Sharp: make the window wide enough for two columns (it can still be resized)
        if not w.sharpSized then
            w.sharpSized = true
            if (w.w or 0) < 880 then w.w = 880 end
            if (w.h or 0) < 600 then w.h = 600 end
        end
    end
    local TB_H = UI.sharp and 40 or 34
    win = CreateFrame("Frame", "AimbotUIWindow", UIParent)
    win:SetFrameStrata("MEDIUM")
    win:SetToplevel(true)
    win:SetClampedToScreen(true)
    win:SetMovable(true)
    win:SetResizable(true)
    if win.SetResizeBounds then
        win:SetResizeBounds(620, 400, 1200, 960)
    elseif win.SetMinResize then
        win:SetMinResize(620, 400)
    end
    win:SetSize(w.w, w.h)
    if w.point then
        win:SetPoint(w.point[1], UIParent, w.point[2], w.point[3], w.point[4])
    else
        win:SetPoint("CENTER")
    end
    table.insert(UISpecialFrames, "AimbotUIWindow")

    bgTex = win:CreateTexture(nil, "BACKGROUND")
    bgTex:SetAllPoints()

    -- Classic style: a Blizzard dialog border and background around the window.
    if UI.classic then
        local deco = BackdropFrame("Frame", win)
        deco:SetFrameLevel(win:GetFrameLevel())
        UI._deco = deco
    end

    local function Edge(p1, p2, width, height)
        local t = win:CreateTexture(nil, "BORDER")
        t:SetPoint(p1); t:SetPoint(p2)
        if width then t:SetWidth(width); edgeVertical[t] = true end
        if height then t:SetHeight(height) end
        table.insert(borderEdges, t)
    end
    Edge("TOPLEFT", "TOPRIGHT", nil, 1)
    Edge("BOTTOMLEFT", "BOTTOMRIGHT", nil, 1)
    Edge("TOPLEFT", "BOTTOMLEFT", 1, nil)
    Edge("TOPRIGHT", "BOTTOMRIGHT", 1, nil)

    -- Soft drop shadow: three faint rings just outside the window edge (modern style).
    for i, a in ipairs(UI.classic and {} or { 0.30, 0.16, 0.07 }) do
        local o, prev = i * 2, (i - 1) * 2
        local function S(p1, x1, y1, p2, x2, y2)
            local t = win:CreateTexture(nil, "BACKGROUND", nil, -8)
            t:SetColorTexture(0, 0, 0, a)
            t:SetPoint(p1, win, p1, x1, y1)
            t:SetPoint(p2, win, p2, x2, y2)
        end
        S("TOPLEFT", -o, o, "TOPRIGHT", o, prev)              -- top band
        S("BOTTOMLEFT", -o, -prev, "BOTTOMRIGHT", o, -o)       -- bottom band
        S("TOPLEFT", -o, prev, "BOTTOMLEFT", -prev, -prev)     -- left band
        S("TOPRIGHT", prev, prev, "BOTTOMRIGHT", o, -prev)     -- right band
    end

    -- Title bar
    local tb = CreateFrame("Frame", nil, win)
    tb:SetPoint("TOPLEFT", 1, -1)
    tb:SetPoint("TOPRIGHT", -1, -1)
    tb:SetHeight(TB_H)
    tb:EnableMouse(true)
    tb:RegisterForDrag("LeftButton")
    titleBG = tb:CreateTexture(nil, "BACKGROUND")
    titleBG:SetAllPoints()
    titleBar = tb
    tb:SetScript("OnDragStart", function() if not W().locked then win:StartMoving() end end)
    tb:SetScript("OnDragStop", function() win:StopMovingOrSizing(); SavePosition() end)

    local mark = tb:CreateTexture(nil, "ARTWORK")
    mark:SetPoint("LEFT", 12, 0)
    mark:SetSize(4, 16)
    UI.Accent(mark, 1)
    local title = UI.Text(tb, "AIMBOT UI", 3, 1, 1, 1)
    if UI.classic then title:SetTextColor(GOLD[1], GOLD[2], GOLD[3]) end
    title:SetPoint("LEFT", mark, "RIGHT", 8, 0)
    -- the version: plain small text in the notes colour, no box behind it
    local ver = UI.Text(tb, "v" .. NS.version, -3, 0.62, 0.62, 0.67)
    ver:SetPoint("BOTTOMLEFT", title, "BOTTOMRIGHT", 8, 1)
    UI._title, UI._ver, UI._mark = title, ver, mark
    if UI.sharp then
        -- a small crosshair logo in front of a larger title; the version moves to the side menu
        mark:SetAlpha(0)
        local ring = UI.Round(tb, "ARTWORK", 20)
        ring:SetPoint("LEFT", tb, "LEFT", 14, 0)
        UI.Accent(ring, 1)
        local hole = UI.Round(tb, "ARTWORK", 14)
        hole:SetDrawLayer("ARTWORK", 2)
        hole:SetPoint("CENTER", ring, "CENTER", 0, 0)
        local dot = UI.Round(tb, "ARTWORK", 6)
        dot:SetDrawLayer("ARTWORK", 3)
        dot:SetPoint("CENTER", ring, "CENTER", 0, 0)
        UI.Accent(dot, 1)
        UI._logo, UI._logoHole, UI._logoParts = ring, hole, { ring, hole, dot }
        title:SetText("Aimbot UI")
        SetFontSafe(title, (W().fontSize or 12) + 5)
        texts[title] = 5
        title:ClearAllPoints()
        title:SetPoint("LEFT", ring, "RIGHT", 10, 0)
    end

    local close = CreateFrame("Button", nil, tb)
    close:SetSize(28, 24)
    close:SetPoint("RIGHT", -5, 0)
    if UI.sharp then
        close:SetSize(22, 22)
        close:SetPoint("RIGHT", -10, 0)
        Edges(close, 1, 1, 1, 0.16, "BORDER")
    end
    local closeHL = close:CreateTexture(nil, "HIGHLIGHT")
    closeHL:SetAllPoints()
    closeHL:SetColorTexture(0.85, 0.22, 0.25, 0.85)
    local closeX = UI.Text(close, "X", 0, 0.70, 0.70, 0.75)
    closeX:SetPoint("CENTER", 0, 0)
    close:SetScript("OnEnter", function() closeX:SetTextColor(1, 1, 1) end)
    close:SetScript("OnLeave", function() closeX:SetTextColor(0.70, 0.70, 0.75) end)
    close:SetScript("OnClick", function() win:Hide() end)

    local tline = tb:CreateTexture(nil, "ARTWORK")
    tline:SetPoint("BOTTOMLEFT", tb, "BOTTOMLEFT", 0, 0)
    tline:SetPoint("BOTTOMRIGHT", tb, "BOTTOMRIGHT", 0, 0)
    tline:SetHeight(1)
    UI.Accent(tline, 0.55)
    UI._tline = tline

    -- Sidebar
    sidebar = CreateFrame("Frame", nil, win)
    sidebar:SetPoint("TOPLEFT", 1, -(TB_H + 1))
    sidebar:SetPoint("BOTTOMLEFT", 1, 1)
    sidebar:SetWidth(SIDEBAR_W)
    sideBG = sidebar:CreateTexture(nil, "BACKGROUND")
    sideBG:SetAllPoints()
    local sline = sidebar:CreateTexture(nil, "ARTWORK")
    sline:SetPoint("TOPRIGHT", sidebar, "TOPRIGHT", 0, 0)
    sline:SetPoint("BOTTOMRIGHT", sidebar, "BOTTOMRIGHT", 0, 0)
    sline:SetWidth(1)
    sline:SetColorTexture(1, 1, 1, 0.06)

    -- The side menu scrolls, because an open dropdown can be taller than the window.
    local sideScroll = CreateFrame("ScrollFrame", nil, sidebar)
    sideScroll:SetPoint("TOPLEFT", sidebar, "TOPLEFT", 0, -40)
    sideScroll:SetPoint("BOTTOMRIGHT", sidebar, "BOTTOMRIGHT", -1, UI.sharp and 24 or 0)
    if UI.sharp then
        ver:ClearAllPoints()
        ver:SetParent(sidebar)
        ver:SetPoint("BOTTOMLEFT", sidebar, "BOTTOMLEFT", 12, 8)
    end
    local sideChild = CreateFrame("Frame", nil, sideScroll)
    sideChild:SetSize(SIDEBAR_W - 1, 10)
    sideScroll:SetScrollChild(sideChild)
    sideScroll:EnableMouseWheel(true)
    sideScroll:SetScript("OnMouseWheel", function(self, delta)
        local range = self:GetVerticalScrollRange() or 0
        self:SetVerticalScroll(math.max(0, math.min(range, self:GetVerticalScroll() - delta * 40)))
    end)

    ----------------------------------------------------------------
    -- Search box: finds any setting by name, in every tab
    ----------------------------------------------------------------
    local resultsChild = CreateFrame("Frame", nil, sideScroll)
    resultsChild:SetSize(SIDEBAR_W - 1, 10)
    resultsChild:Hide()
    local resultButtons, searchBox, searchResults = {}, nil, {}
    local RESULT_H = 40
    local flash, flashTex, flashToken = nil, nil, 0

    local sHolder = CreateFrame("Frame", nil, sidebar)
    sHolder:SetPoint("TOPLEFT", sidebar, "TOPLEFT", 8, -8)
    sHolder:SetPoint("TOPRIGHT", sidebar, "TOPRIGHT", -9, -8)
    sHolder:SetHeight(26)
    local sEdge = sHolder:CreateTexture(nil, "BACKGROUND")
    sEdge:SetAllPoints()
    sEdge:SetColorTexture(1, 1, 1, 0.10)
    local sFill = sHolder:CreateTexture(nil, "BORDER")
    sFill:SetPoint("TOPLEFT", 1, -1)
    sFill:SetPoint("BOTTOMRIGHT", -1, 1)
    sFill:SetColorTexture(0.05, 0.05, 0.06, 1)
    searchBox = CreateFrame("EditBox", nil, sHolder)
    searchBox:SetPoint("TOPLEFT", sHolder, "TOPLEFT", 8, -2)
    searchBox:SetPoint("BOTTOMRIGHT", sHolder, "BOTTOMRIGHT", -24, 2)
    searchBox:SetAutoFocus(false)
    searchBox:SetMaxLetters(40)
    SetFontSafe(searchBox, W().fontSize)
    texts[searchBox] = 0
    roles[searchBox] = "body"
    searchBox:SetTextColor(W().text[1], W().text[2], W().text[3])
    local sHint = UI.Text(sHolder, "Search settings...", -1, 0.62, 0.62, 0.67)
    sHint:SetPoint("LEFT", sHolder, "LEFT", 9, 0)
    sHint:SetPoint("RIGHT", sHolder, "RIGHT", -24, 0)
    sHint:SetWordWrap(false)
    local sClear = CreateFrame("Button", nil, sHolder)
    sClear:SetSize(20, 22)
    sClear:SetPoint("RIGHT", sHolder, "RIGHT", -2, 0)
    local sx = UI.Text(sClear, "x", 1, 0.62, 0.62, 0.67)
    sx:SetPoint("CENTER")
    sClear:Hide()

    local function QueryText()
        local q = searchBox:GetText()
        if type(q) ~= "string" then return "" end
        return (q:gsub("^%s+", ""):gsub("%s+$", ""))
    end

    local function LeaveSearch()
        resultsChild:Hide()
        sideChild:Show()
        sideScroll:SetScrollChild(sideChild)
        UI.LayoutSidebar(true)
    end

    -- Finds settings. Every word typed must appear in the setting's name, its area or its tab.
    function UI.Search(query)
        local words = {}
        for w in tostring(query or ""):lower():gmatch("%S+") do words[#words + 1] = w end
        local found = {}
        if #words == 0 then return found end
        local function hit(hay)
            for _, w in ipairs(words) do
                if not hay:find(w, 1, true) then return false end
            end
            return true
        end
        local phrase = table.concat(words, " ")
        local function closeness(text)       -- 0 exact, 1 starts with it, 2 contains it, 3 only the words
            local l = text:lower()
            if l == phrase then return 0 end
            local at = l:find(phrase, 1, true)
            if at == 1 then return 1 end
            return at and 2 or 3
        end
        local function anyIn(hay)
            for _, w in ipairs(words) do
                if hay:find(w, 1, true) then return true end
            end
            return false
        end
        for order, t in ipairs(tabList) do
            local tabName = t.label or t.key
            if hit(tabName:lower()) then
                found[#found + 1] = { text = tabName, where = "Tab", t = t, rank = 0, order = order, close = closeness(tabName) }
            end
            for _, card in ipairs(t.page.cards) do
                local area = card.title
                local base = (tabName .. " " .. (area or "")):lower()
                if area and hit(base) then
                    found[#found + 1] = { text = area, where = tabName, t = t, card = card, rank = 3, order = order, area = true, close = closeness(area) }
                end
                for _, row in ipairs(card.allRows or card.rows) do
                    local label = row.label and row.label:lower()
                    local where = tabName .. (area and (" > " .. area) or "")
                    if label and anyIn(label) and hit(label .. " " .. base) then
                        found[#found + 1] = { text = row.label, where = where, t = t, card = card, row = row,
                            rank = hit(label) and 1 or 2, order = order, close = closeness(row.label) }
                    elseif row.note and hit(row.note:lower()) then
                        found[#found + 1] = { text = (row.note:gsub("%s+", " ")), where = where,
                            t = t, card = card, row = row, rank = 4, order = order, note = true, close = 3 }
                    end
                end
            end
        end
        table.sort(found, function(a, b)
            if a.rank ~= b.rank then return a.rank < b.rank end
            if a.close ~= b.close then return a.close < b.close end
            if #a.text ~= #b.text then return #a.text < #b.text end
            return a.order < b.order
        end)
        while #found > 40 do found[#found] = nil end
        return found
    end

    -- Brief glow on the setting you jumped to, and scroll it into view.
    local function Reveal(row)
        if not row or not row.frame then return end
        if not flash then
            flash = CreateFrame("Frame", nil, UIParent)
            flashTex = flash:CreateTexture(nil, "OVERLAY")
            flashTex:SetAllPoints()
            flash:EnableMouse(false)
            flash:Hide()
        end
        flash:SetParent(row.frame)
        flash:ClearAllPoints()
        flash:SetPoint("TOPLEFT", row.frame, "TOPLEFT", -6, 2)
        flash:SetPoint("BOTTOMRIGHT", row.frame, "BOTTOMRIGHT", 6, -2)
        local c = W().accent
        flashTex:SetColorTexture(c[1], c[2], c[3], 0.30)
        flash:Show()
        flashToken = flashToken + 1
        local mine = flashToken
        C_Timer.After(1.8, function() if flashToken == mine then flash:Hide() end end)
    end

    local function ScrollTo(page, row)
        local ok = pcall(function()
            local top, ctop = row.frame:GetTop(), page.child:GetTop()
            if type(top) == "number" and type(ctop) == "number" then
                local range = page.frame:GetVerticalScrollRange() or 0
                page.frame:SetVerticalScroll(math.max(0, math.min(range, ctop - top - 40)))
            end
        end)
        return ok
    end

    local function GoTo(r)
        if currentTab ~= r.t.key then SelectTab(r.t.key) end
        local page = r.t.page
        if page.menuMode and r.card and not r.card.pinned then page:Open(r.card) end
        if r.card and UI.IsFolded(page, r.card) then UI.SetFolded(page, r.card, false); page:Reflow() end
        searchBox:SetText("")
        searchBox:ClearFocus()
        LeaveSearch()
        if r.row then
            local target = r.row.host or r.row          -- grouped settings: their line
            Reveal(target)
            C_Timer.After(0, function() ScrollTo(page, target) end)
            if r.row.pop then C_Timer.After(0.05, function() pcall(r.row.pop.Open) end) end
        end
    end

    local function ShowResults(list)
        searchResults = list
        sideChild:Hide()
        resultsChild:Show()
        sideScroll:SetScrollChild(resultsChild)
        sideScroll:SetVerticalScroll(0)
        for i, r in ipairs(list) do
            local b = resultButtons[i]
            if not b then
                b = CreateFrame("Button", nil, resultsChild)
                b:SetHeight(RESULT_H)
                local hl = b:CreateTexture(nil, "HIGHLIGHT")
                hl:SetAllPoints()
                hl:SetColorTexture(1, 1, 1, 0.06)
                local ln = b:CreateTexture(nil, "BORDER")
                ln:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 10, 0)
                ln:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -8, 0)
                ln:SetHeight(1)
                ln:SetColorTexture(1, 1, 1, 0.06)
                b.main = UI.Text(b, "", 0)
                b.main:SetPoint("TOPLEFT", b, "TOPLEFT", 12, -5)
                b.main:SetPoint("RIGHT", b, "RIGHT", -8, 0)
                b.main:SetWordWrap(false)
                b.sub = UI.Text(b, "", -2, 0.62, 0.62, 0.67)
                b.sub:SetPoint("TOPLEFT", b.main, "BOTTOMLEFT", 0, -3)
                b.sub:SetPoint("RIGHT", b, "RIGHT", -8, 0)
                b.sub:SetWordWrap(false)
                resultButtons[i] = b
            end
            b:ClearAllPoints()
            b:SetPoint("TOPLEFT", resultsChild, "TOPLEFT", 0, -4 - (i - 1) * RESULT_H)
            b:SetPoint("TOPRIGHT", resultsChild, "TOPRIGHT", -2, -4 - (i - 1) * RESULT_H)
            b.main:SetText(r.text)
            b.sub:SetText(r.where)
            b:SetScript("OnClick", function() GoTo(r) end)
            b:Show()
        end
        for i = #list + 1, #resultButtons do resultButtons[i]:Hide() end
        if not resultButtons.none then
            resultButtons.none = UI.Text(resultsChild, "Nothing matches that.", -1, 0.62, 0.62, 0.67)
            resultButtons.none:SetPoint("TOPLEFT", resultsChild, "TOPLEFT", 14, -12)
        end
        resultButtons.none:SetShown(#list == 0)
        resultsChild:SetHeight(math.max(30, #list * RESULT_H + 12))
    end

    local function Refresh()
        local q = QueryText()
        sHint:SetShown(q == "" and not searchBox:HasFocus())
        sClear:SetShown(q ~= "")
        if q == "" then
            if resultsChild:IsShown() then LeaveSearch() end
        else
            ShowResults(UI.Search(q))
        end
    end
    searchBox:SetScript("OnTextChanged", Refresh)
    searchBox:SetScript("OnEditFocusGained", function()
        local a = W().accent
        sEdge:SetColorTexture(a[1], a[2], a[3], 1)
        Refresh()
    end)
    searchBox:SetScript("OnEditFocusLost", function()
        sEdge:SetColorTexture(1, 1, 1, 0.10)
        Refresh()
    end)
    searchBox:SetScript("OnEnterPressed", function()
        if searchResults[1] and QueryText() ~= "" then GoTo(searchResults[1]) else searchBox:ClearFocus() end
    end)
    searchBox:SetScript("OnEscapePressed", function()
        if QueryText() ~= "" then searchBox:SetText("") else searchBox:ClearFocus() end
    end)
    sClear:SetScript("OnClick", function() searchBox:SetText(""); searchBox:ClearFocus() end)
    UI._searchBox = searchBox

    content = CreateFrame("Frame", nil, win)
    content:SetPoint("TOPLEFT", sidebar, "TOPRIGHT", 0, 0)
    content:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", -1, FOOTER_H + 1)

    -- Resize grip + footer
    grip = CreateFrame("Button", nil, win)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", -2, 2)
    for i, size in ipairs({ 12, 8, 4 }) do
        local g = grip:CreateTexture(nil, "OVERLAY")
        g:SetPoint("BOTTOMRIGHT", 0, (i - 1) * 5)
        g:SetSize(size, 3)
        UI.Accent(g, 0.7)
    end
    grip:SetScript("OnMouseDown", function() if not W().locked then win:StartSizing("BOTTOMRIGHT") end end)
    grip:SetScript("OnMouseUp", function() win:StopMovingOrSizing(); SaveSize(); SavePosition() end)

    -- Footer: Test menu on the left, Undo and Close on the right
    local footer = CreateFrame("Frame", nil, win)
    footer:SetPoint("BOTTOMLEFT", sidebar, "BOTTOMRIGHT", 0, 0)
    footer:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", -1, 1)
    footer:SetHeight(FOOTER_H)
    local fline = footer:CreateTexture(nil, "ARTWORK")
    fline:SetPoint("TOPLEFT", footer, "TOPLEFT", 0, 0)
    fline:SetPoint("TOPRIGHT", footer, "TOPRIGHT", 0, 0)
    fline:SetHeight(1)
    fline:SetColorTexture(1, 1, 1, 0.06)
    UI._footer = footer

    local closeBtn = UI.MakeButton(footer, UI.sharp and "Done" or "Close", UI.sharp and 96 or 84, 24)
    closeBtn:SetPoint("RIGHT", footer, "RIGHT", -22, 0)
    closeBtn:SetScript("OnClick", function() win:Hide() end)
    if UI.sharp then
        -- Done: outlined in the highlight colour
        for _, e in ipairs(Edges(closeBtn, 1, 1, 1, 1, "BORDER")) do UI.Accent(e, 0.9) end
    end
    local undoBtn = UI.MakeButton(footer, "Undo", 84, 24)
    undoBtn:SetPoint("RIGHT", closeBtn, "LEFT", -8, 0)
    undoBtn:SetScript("OnClick", function()
        local ok, label = UI.Undo()
        if ok then NS.Print("undid: " .. tostring(label)) else NS.Print("nothing to undo") end
    end)
    Tip(undoBtn, "Undo", "Puts back your last change (switches, sliders, dropdowns and colours), one at a time.")
    UI._undoBtn, UI._closeBtn = undoBtn, closeBtn
    function UI.UpdateUndo()
        local n = #undoStack
        pcall(undoBtn.SetAlpha, undoBtn, n > 0 and 1 or 0.45)
        if undoBtn.label then pcall(undoBtn.label.SetText, undoBtn.label, n > 0 and ("Undo (" .. n .. ")") or "Undo") end
    end

    local testBtn = UI.MakeButton(footer, "Test...", UI.sharp and 76 or 96, 24)
    testBtn:SetPoint("LEFT", footer, "LEFT", 12, 0)
    if UI.sharp then
        -- Reset tab and Reload UI sit next to Test... (the header has no Reset tab button in this style)
        local resetBtn = UI.MakeButton(footer, "Reset tab", 86, 24)
        resetBtn:SetPoint("LEFT", testBtn, "RIGHT", 6, 0)
        resetBtn:SetScript("OnClick", function()
            if currentTab and tabs[currentTab] and tabs[currentTab].module then NS.ResetModule(currentTab) end
        end)
        Tip(resetBtn, "Reset tab", "Puts every setting of the tab you're on back to its default.")
        local reloadBtn = UI.MakeButton(footer, "Reload UI", 86, 24)
        reloadBtn:SetPoint("LEFT", resetBtn, "RIGHT", 6, 0)
        reloadBtn:SetScript("OnClick", function() if ReloadUI then ReloadUI() end end)
        UI._resetBtn, UI._reloadBtn = resetBtn, reloadBtn
    end
    Tip(testBtn, "Test", "Try any feature that has a test: pick it from the list.")
    UI._testBtn = testBtn
    local testMenu
    function UI.ToggleTestMenu()
        if testMenu and testMenu:IsShown() then testMenu:Hide(); return end
        if not testMenu then
            testMenu = CreateFrame("Frame", nil, win, BackdropTemplateMixin and "BackdropTemplate" or nil)
            testMenu:SetFrameStrata("DIALOG")
            local bg = testMenu:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetColorTexture(0.06, 0.06, 0.07, 0.97)
            local edge = testMenu:CreateTexture(nil, "BORDER")
            edge:SetPoint("TOPLEFT", -1, 1); edge:SetPoint("BOTTOMRIGHT", 1, -1)
            edge:SetColorTexture(1, 1, 1, 0.15)
            testMenu.rows = {}
            testMenu:EnableMouse(true)
        end
        local list = {}
        for _, t in ipairs(UI.tests) do list[#list + 1] = t end
        table.sort(list, function(a, b) return a.name < b.name end)
        local ROW = 22
        for i, t in ipairs(list) do
            local r = testMenu.rows[i]
            if not r then
                r = CreateFrame("Button", nil, testMenu)
                r:SetHeight(ROW)
                local hl = r:CreateTexture(nil, "HIGHLIGHT")
                hl:SetAllPoints()
                hl:SetColorTexture(1, 1, 1, 0.08)
                r.fs = UI.Text(r, "", -1)
                r.fs:SetPoint("LEFT", r, "LEFT", 10, 0)
                r.fs:SetPoint("RIGHT", r, "RIGHT", -10, 0)
                r.fs:SetJustifyH("LEFT")
                testMenu.rows[i] = r
            end
            r:ClearAllPoints()
            r:SetPoint("TOPLEFT", testMenu, "TOPLEFT", 0, -4 - (i - 1) * ROW)
            r:SetPoint("TOPRIGHT", testMenu, "TOPRIGHT", 0, -4 - (i - 1) * ROW)
            local extra = (t.label ~= "" and ("  |cff9a9aa0" .. t.label .. "|r") or "")
            r.fs:SetText(t.name .. extra)
            r.test = t
            r:SetScript("OnClick", function(self)
                testMenu:Hide()
                local ok, err = pcall(self.test.run)
                if not ok then NS.ReportError("test " .. self.test.name, err) end
            end)
            r:Show()
        end
        for i = #list + 1, #testMenu.rows do testMenu.rows[i]:Hide() end
        testMenu:SetSize(260, math.max(1, #list) * ROW + 8)
        testMenu:ClearAllPoints()
        testMenu:SetPoint("BOTTOMLEFT", testBtn, "TOPLEFT", 0, 4)
        testMenu:Show()
        UI._testMenu = testMenu
    end
    testBtn:SetScript("OnClick", UI.ToggleTestMenu)
    win:HookScript("OnHide", function() if testMenu then testMenu:Hide() end; UI.ClosePops() end)

    -- Tabs ----------------------------------------------------------
    local lastGroup2
    local sideEntries = {}        -- { group = fontstring } or { tab = t }
    local SUB_H = 26

    -- Places every group label, tab and (for the open tab) its dropdown rows.
    function UI.LayoutSidebar(resetScroll)
        local y = -10
        for _, e in ipairs(sideEntries) do
            if e.group then
                y = y - (UI.sharp and 10 or 14)
                e.group:ClearAllPoints()
                e.group:SetPoint("TOPLEFT", sideChild, "TOPLEFT", UI.sharp and 12 or 14, y)
                if e.line then
                    e.line:ClearAllPoints()
                    e.line:SetPoint("LEFT", e.group, "RIGHT", 8, 0)
                    e.line:SetPoint("RIGHT", sideChild, "RIGHT", -12, 0)
                end
                y = y - (UI.sharp and 18 or 20)
            else
                local t = e.tab
                t.btn:ClearAllPoints()
                t.btn:SetPoint("TOPLEFT", sideChild, "TOPLEFT", UI.sharp and 8 or 6, y)
                t.btn:SetPoint("TOPRIGHT", sideChild, "TOPRIGHT", UI.sharp and -9 or -7, y)
                y = y - (UI.sharp and 28 or 30)
                if t.arrow then t.arrow:SetText(t.expanded and "-" or "+") end
                for i, sub in ipairs(t.subs or {}) do
                    if t.expanded then
                        sub.btn:ClearAllPoints()
                        sub.btn:SetPoint("TOPLEFT", sideChild, "TOPLEFT", 20, y)
                        sub.btn:SetPoint("TOPRIGHT", sideChild, "TOPRIGHT", -7, y)
                        sub.btn:Show()
                        local on = currentTab == t.key and t.page.view == sub.card
                        sub.sel:SetShown(on)
                        sub.bar:SetShown(on)
                        y = y - SUB_H
                    else
                        sub.btn:Hide()
                    end
                end
                if t.expanded and t.subs and #t.subs > 0 then y = y - 4 end
            end
        end
        sideChild:SetHeight(-y + 10)
        if resetScroll then sideScroll:SetVerticalScroll(0) end
    end

    local function NewTab(key, label, buildFn, mod)
        if mod and mod.group and mod.group ~= lastGroup2 then
            lastGroup2 = mod.group
            local g = UI.Text(sideChild, GROUP_LABEL[mod.group] or string.upper(mod.group), -2, 0.50, 0.50, 0.56)
            if UI.sharp then
                UI._groupLabels = UI._groupLabels or {}
                table.insert(UI._groupLabels, g)
            end
            local line = sideChild:CreateTexture(nil, "ARTWORK")
            line:SetHeight(1)
            line:SetColorTexture(1, 1, 1, 0.07)
            sideEntries[#sideEntries + 1] = { group = g, line = line }
        end

        local btn = CreateFrame("Button", nil, sideChild)
        btn:SetHeight(UI.sharp and 24 or 28)

        local sel = btn:CreateTexture(nil, "BACKGROUND")
        sel:SetAllPoints()
        UI.Accent(sel, 0.13)
        sel:Hide()
        local selGlow
        if UI.sharp then
            -- a soft glow at the start of the selected line
            selGlow = btn:CreateTexture(nil, "BACKGROUND", nil, 1)
            selGlow:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 0)
            selGlow:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 0, 0)
            selGlow:SetWidth(46)
            UI.Accent(selGlow, 0.12)
            selGlow:Hide()
        end
        local selBar = btn:CreateTexture(nil, "ARTWORK")
        selBar:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, -6)
        selBar:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 0, 6)
        selBar:SetWidth(3)
        UI.Accent(selBar, 1)
        selBar:Hide()
        local pill, pillEdge
        if UI.sharp then
            -- rounded button: a thin outline (the outer pill) with the fill drawn 1px inside it.
            -- The old square selection art stays hidden in this style.
            sel:SetAlpha(0); selBar:SetAlpha(0)
            if selGlow then selGlow:SetAlpha(0) end
            pillEdge = MakePill(btn, "BACKGROUND", 2, 0, 24)
            pill = MakePill(btn, "BACKGROUND", 3, 1, 24)
        else
            local hl = btn:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(1, 1, 1, 0.05)
        end

        local dot
        -- A "(...)" note at the end of a name is drawn smaller and grey so long names fit
        local main, note = label:match("^(.-)%s*(%b())$")
        if not main or main == "" then main, note = label, nil end
        local fs = UI.Text(btn, main, UI.sharp and -1 or 0)
        fs:SetWordWrap(false)
        local noteFs
        if note then
            noteFs = UI.Text(btn, note, -3, 0.62, 0.62, 0.67)
            noteFs:SetPoint("LEFT", fs, "RIGHT", 4, 0)
            noteFs:SetWordWrap(false)
        end
        local function LabelRight(anchor, rel, x)
            if noteFs then noteFs:SetPoint("RIGHT", anchor, rel, x, 0)
            else fs:SetPoint("RIGHT", anchor, rel, x, 0) end
        end
        local power
        if mod and UI.sharp then
            fs:SetPoint("LEFT", btn, "LEFT", 12, 0)
            power = UI.MakePower(btn, key, label)
            power:SetPoint("RIGHT", btn, "RIGHT", -6, 0)
        elseif mod then
            dot = UI.Round(btn, "ARTWORK", 7)
            dot:SetPoint("LEFT", btn, "LEFT", 12, 0)
            fs:SetPoint("LEFT", dot, "RIGHT", 9, 0)
        else
            fs:SetPoint("LEFT", btn, "LEFT", 14, 0)
        end
        local arrow = UI.Text(btn, "+", 1, 0.50, 0.50, 0.56)
        arrow:SetPoint("RIGHT", btn, "RIGHT", -10, 0)
        LabelRight(arrow, "LEFT", -6)
        btn:SetScript("OnClick", function()
            local t = tabs[key]
            if currentTab == key and t and t.page.menuMode then
                -- already here: the + / - opens and closes its dropdown
                t.expanded = not t.expanded
                UI.LayoutSidebar(true)
            else
                SelectTab(key)
            end
        end)

        local header, sw = BuildHeader(content, label, mod and mod.desc or "Window look, module switches and maintenance.",
            mod and key or nil)
        -- Sharp style: a live preview under the header for modules that draw something
        local above = header
        if UI.sharp and mod and type(mod.LivePreview) == "function" then
            local box = CreateFrame("Frame", nil, content)
            box:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 10, -8)
            box:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", -24, -8)
            box:SetHeight(mod.livePreviewHeight or 74)
            box:Hide()
            local bg = box:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetColorTexture(0, 0, 0, 0.30)
            Edges(box, 1, 1, 1, 0.07, "BORDER")
            local cap = UI.Text(box, "PREVIEW", -4, 0.62, 0.62, 0.67)
            cap:SetPoint("TOPLEFT", box, "TOPLEFT", 8, -6)
            cap:SetAlpha(0.7)
            local stage = CreateFrame("Frame", nil, box)
            stage:SetPoint("TOPLEFT", box, "TOPLEFT", 4, -4)
            stage:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", -4, 4)
            local okP, refresh = pcall(mod.LivePreview, stage, box)
            if not okP then NS.ReportError("preview " .. label, refresh); refresh = nil end
            if type(refresh) == "function" then
                local wait = 0
                box:SetScript("OnUpdate", function(_, el)
                    wait = wait - el
                    if wait > 0 then return end
                    wait = 0.15
                    local okR, e = pcall(refresh, stage, el)
                    if not okR then box:SetScript("OnUpdate", nil); NS.ReportError("preview " .. label, e) end
                end)
            end
            UI._previews = UI._previews or {}
            UI._previews[key] = box
            above = box
        end
        local holder = CreateFrame("Frame", nil, content)
        holder:SetPoint("TOPLEFT", above, above == header and "BOTTOMLEFT" or "BOTTOMLEFT", above == header and 6 or -4, -6)
        holder:SetPoint("BOTTOMRIGHT", content, "BOTTOMRIGHT", -2, 4)
        local page = UI.NewPage(holder)
        if mod then page.moduleKey, page.moduleName = key, label end
        local ok, err = pcall(buildFn, page)
        if not ok then NS.ReportError("tab " .. label, err) end
        local ok2, err2 = pcall(page.Finish, page)
        if not ok2 then NS.ReportError("tab " .. label .. " menu", err2) end
        page:Reflow()

        local t = { key = key, label = label, btn = btn, page = page, sel = sel, selBar = selBar,
            header = header, switch = sw, dot = dot, module = mod and true or false,
            power = power, labelFs = fs, selGlow = selGlow, preview = UI._previews and UI._previews[key] }
        tabs[key] = t
        table.insert(tabList, t)
        sideEntries[#sideEntries + 1] = { tab = t }

        if pill then
            t.pill = pill
            -- the fill is a solid colour worked out from the side menu, so the outline reads as an
            -- outline: dark and a touch lighter than the menu normally, lighter on hover, and
            -- tinted with the theme's accent (with an accent outline) when selected
            local function Fill()
                local sr, sg, sb = SideColor()
                local c = W().accent
                if currentTab == key then return Mix(sr, sg, sb, c[1], c[2], c[3], 0.32) end
                if t.hover then return Mix(sr, sg, sb, 1, 1, 1, 0.12) end
                return Mix(sr, sg, sb, 1, 1, 1, 0.05)
            end
            function t.PaintPill()
                local r, g, b = Fill()
                pill.SetColor(r, g, b, 1)
                if currentTab == key then
                    local c = W().accent
                    pillEdge.SetColor(c[1], c[2], c[3], 0.95)
                else
                    pillEdge.SetColor(1, 1, 1, t.hover and 0.22 or 0.10)
                end
                if power then power.Refresh() end
            end
            if power then power.behind = Fill end
            btn:SetScript("OnEnter", function() t.hover = true; t.PaintPill() end)
            btn:SetScript("OnLeave", function() t.hover = false; t.PaintPill() end)
            if power then
                -- the power button sits on top of the pill: keep the hover look while over it
                power:HookScript("OnEnter", function() t.hover = true; t.PaintPill() end)
                power:HookScript("OnLeave", function() t.hover = false; t.PaintPill() end)
            end
            t.PaintPill()
        end

        if UI.sharp and page.menuMode and page.areas then
            -- areas are tabs along the top of the page, not a list in the side menu
            header.AddTabs(page)
            arrow:Hide()
            fs:ClearAllPoints()
            fs:SetPoint("LEFT", btn, "LEFT", 12, 0)
            if noteFs then noteFs:ClearAllPoints(); noteFs:SetPoint("LEFT", fs, "RIGHT", 4, 0) end
            LabelRight(power or btn, power and "LEFT" or "RIGHT", -6)
        -- the dropdown: one row per area of this tab
        elseif page.menuMode and page.areas then
            arrow:Show()
            t.arrow = arrow
            t.subs = {}
            for _, card in ipairs(page.areas) do
                local sb = CreateFrame("Button", nil, sideChild)
                sb:SetHeight(SUB_H)
                sb:Hide()
                local guide = sb:CreateTexture(nil, "BORDER")        -- thin vertical guide line, joins up between rows
                guide:SetPoint("TOPLEFT", sb, "TOPLEFT", 4, 0)
                guide:SetPoint("BOTTOMLEFT", sb, "BOTTOMLEFT", 4, 0)
                guide:SetWidth(1)
                guide:SetColorTexture(1, 1, 1, 0.10)
                local ssel = sb:CreateTexture(nil, "BACKGROUND")
                ssel:SetPoint("TOPLEFT", sb, "TOPLEFT", 4, 0)
                ssel:SetPoint("BOTTOMRIGHT", sb, "BOTTOMRIGHT", 0, 0)
                UI.Accent(ssel, 0.22)
                ssel:Hide()
                local sbar = sb:CreateTexture(nil, "ARTWORK")
                sbar:SetPoint("TOPLEFT", sb, "TOPLEFT", 3, 0)
                sbar:SetPoint("BOTTOMLEFT", sb, "BOTTOMLEFT", 3, 0)
                sbar:SetWidth(2)
                UI.Accent(sbar, 1)
                sbar:Hide()
                local shl = sb:CreateTexture(nil, "HIGHLIGHT")
                shl:SetPoint("TOPLEFT", sb, "TOPLEFT", 4, 0)
                shl:SetPoint("BOTTOMRIGHT", sb, "BOTTOMRIGHT", 0, 0)
                shl:SetColorTexture(1, 1, 1, 0.06)
                local sfs = UI.Text(sb, (card.title:gsub("%s*%b()", "")), -1, 0.80, 0.80, 0.85)   -- side label drops "(...)" notes
                sfs:SetPoint("LEFT", sb, "LEFT", 16, 0)
                sfs:SetPoint("RIGHT", sb, "RIGHT", -6, 0)
                sfs:SetWordWrap(false)
                sb:SetScript("OnClick", function()
                    if currentTab ~= key then SelectTab(key) end
                    t.expanded = true
                    t.page:Open(card)
                end)
                t.subs[#t.subs + 1] = { btn = sb, sel = ssel, bar = sbar, card = card }
            end
        else
            arrow:Hide()
            fs:ClearAllPoints()
            fs:SetPoint("LEFT", btn, "LEFT", UI.sharp and 12 or (dot and 28 or 14), 0)
            if noteFs then noteFs:ClearAllPoints(); noteFs:SetPoint("LEFT", fs, "RIGHT", 4, 0) end
            LabelRight(power or btn, power and "LEFT" or "RIGHT", -6)
        end
    end

    NewTab("general", "General", BuildGeneral, nil)
    for _, key in ipairs(SortedModules()) do
        local m = NS.modules[key]
        NewTab(key, m.name or key, function(page)
            if m.Build then m.Build(page) end
        end, m)
    end

    UI.ApplyStyle()
    SelectTab("general")
    if UI.UpdateUndo then UI.UpdateUndo() end
    win:Hide()
end

function UI.Show(tabKey)
    if not win then Create() end
    win:Show()
    UI.RefreshAll()
    if tabKey and tabs[tabKey] then SelectTab(tabKey) end
end

function UI.Toggle(tabKey)
    if not win then Create() end
    if win:IsShown() and (not tabKey or currentTab == tabKey) then
        win:Hide()
    else
        UI.Show(tabKey)
    end
end

function UI.GetPage(key)
    return tabs[key] and tabs[key].page or nil
end

UI._tabs = tabs

function UI.HasTab(key)
    return key == "general" or NS.modules[key] ~= nil
end

----------------------------------------------------------------------
-- Slash commands
----------------------------------------------------------------------
local ALIASES = {
    lorti = "lorti", skin = "lorti", ui = "lorti", style = "lorti",
    damage = "damage", font = "damage", fonts = "damage", nicedamage = "damage",
    sparkle = "sparkle", flash = "sparkle", buttonflash = "sparkle",
    mana = "manacost", cost = "manacost", costs = "manacost", manacost = "manacost",
    range = "range",
    train = "trainer", training = "trainer", trainer = "trainer",
    double = "doublepress", doublepress = "doublepress", dp = "doublepress", ahk = "doublepress",
    qol = "doublepress", autohotkey = "doublepress",
    memory = "memory", mem = "memory", cache = "memory", leak = "memory", leaks = "memory",
    mute = "mute", chat = "mute", chatmute = "mute", silence = "mute", ignore = "mute",
    fps = "fps", ms = "fps", latency = "fps", ping = "fps", counter = "fps",
    privacy = "privacy", stream = "privacy", streamer = "privacy", incognito = "privacy", private = "privacy",
    diminish = "diminish", dr = "diminish", drs = "diminish", diminishing = "diminish",
    queue = "queuetimer", queuetimer = "queuetimer", pop = "queuetimer",
    plates = "plateicons", icons = "plateicons", plateicons = "plateicons", healer = "plateicons", racial = "plateicons",
    combat = "combatind", combatind = "combatind", incombat = "combatind",
    kick = "interrupt", interrupt = "interrupt", interrupts = "interrupt",
    death = "deathalert", deaths = "deathalert", died = "deathalert", deathalert = "deathalert",
    repair = "durability", dura = "durability", durability = "durability",
    timers = "auratimers", auratimers = "auratimers", dots = "auratimers", auras = "auratimers", duration = "auratimers",
    talent = "talentalert", talents = "talentalert", points = "talentalert", talentalert = "talentalert",
    autoshot = "autoshot", ast = "autoshot", shot = "autoshot", hunter = "autoshot", swing = "autoshot",
    loc = "lossofcontrol", lossofcontrol = "lossofcontrol", control = "lossofcontrol", stun = "lossofcontrol",
    stuns = "lossofcontrol", ccme = "lossofcontrol", losecontrol = "lossofcontrol",
    general = "general", window = "general",
}

----------------------------------------------------------------------
-- Escape menu button
-- Our own button, placed in the game's Escape menu list: in the first gap between its groups of
-- buttons (after Options / Shop), sized to sit between them. Nothing is added to the game's own
-- button list and none of its buttons is moved (that list also holds Log Out / Exit Game, and
-- an addon changing it can get those blocked); ours only lines up with them. If no gap can be
-- found it sits above the menu. Clicking closes the menu and opens the settings window.
----------------------------------------------------------------------
local menuButton

-- The game's menu buttons, top to bottom, with their edges (when they can be read).
-- The game's menu buttons in menu order, with their text. Their positions can't be used: on this
-- client the menu's sizes and positions are hidden from addons (2.18.2 / 2.19.0 measured them and
-- found nothing). Order comes from the layout index the game gives each button.
local function MenuButtons(gm)
    local out = {}
    local all = {}
    local function Walk(f, depth)
        if depth > 4 or #all > 200 then return end
        local ok, kids = pcall(function() return { f:GetChildren() } end)
        if not ok then return end
        for _, k in ipairs(kids) do
            all[#all + 1] = k
            Walk(k, depth + 1)
        end
    end
    Walk(gm, 0)
    UI._menuSeen = #all
    local dbg = {}
    for i, k in ipairs(all) do
        local okT, kind = pcall(k.GetObjectType, k)
        if okT and kind == "Button" and k ~= menuButton then
            local okS, shown = pcall(k.IsShown, k)
            local okX, txt = pcall(k.GetText, k)
            if okX and (txt == nil or txt == "") and k.GetFontString then
                local okF, fs = pcall(k.GetFontString, k)
                if okF and fs then okX, txt = pcall(fs.GetText, fs) end
            end
            if (not okX) or txt == nil or txt == "" then
                -- the label can be a plain text drawn on the button (button.Text) rather than the
                -- button's own text: read the first text region that says something
                local okR, regions = pcall(function() return { k:GetRegions() } end)
                if okR then
                    for _, r in ipairs(regions) do
                        local okO, ro = pcall(r.GetObjectType, r)
                        if okO and ro == "FontString" then
                            local okRT, rt = pcall(r.GetText, r)
                            if okRT and not NS.IsSecret(rt) and type(rt) == "string" and rt ~= "" then okX, txt = true, rt; break end
                        end
                    end
                end
            end
            local li = rawget(k, "layoutIndex")
            local isShown = okS and not NS.IsSecret(shown) and shown == true
            local hasText = okX and not NS.IsSecret(txt) and type(txt) == "string" and txt ~= ""
            if #dbg < 30 then
                dbg[#dbg + 1] = string.format("%s shown=%s text=%s layout=%s", kind, tostring(isShown),
                    hasText and txt or (NS.IsSecret(txt) and "secret" or tostring(txt)),
                    NS.IsSecret(li) and "secret" or tostring(li))
            end
            if isShown and hasText then
                out[#out + 1] = { b = k, text = txt, order = (not NS.IsSecret(li) and type(li) == "number") and li or (1000 + i) }
            end
        end
    end
    table.sort(out, function(x, y) return x.order < y.order end)
    UI._menuFound = #out
    if NS.db then NS.db.menuDebug = dbg end
    return out
end

local function Same(a, b)
    return type(a) == "string" and type(b) == "string" and a:lower() == b:lower()
end

local function PlaceMenuButton()
    local gm = _G.GameMenuFrame
    if not (menuButton and gm) then return end
    local list = MenuButtons(gm)
    menuButton:ClearAllPoints()
    -- In the space after the Shop button (the end of the first group). A see-through guide frame
    -- spans that space (anchored to Shop and AddOns, so nothing is measured); our button is the
    -- game's own button height, centred on the guide and as wide as the game's buttons. The game's
    -- buttons have empty margin around their art, so the space between their frames is smaller
    -- than it looks; a full-height button centred there lines its art up with theirs. (2.19.3
    -- squeezed it into the space, which made it thin and, at zero height, broke the game's button
    -- art: "SetScale(): Scale must be > 0".)
    local shopText = _G.BLIZZARD_STORE or "Shop"
    for i = 1, #list - 1 do
        if Same(list[i].text, shopText) or Same(list[i].text, "Shop") then
            local a, b = list[i], list[i + 1]
            local guide = UI._menuGuide
            if not guide then
                guide = CreateFrame("Frame", nil, UIParent)
                guide:EnableMouse(false)
                UI._menuGuide = guide
            end
            guide:ClearAllPoints()
            guide:SetPoint("TOPLEFT", a.b, "BOTTOMLEFT", 0, 0)
            guide:SetPoint("BOTTOMRIGHT", b.b, "TOPRIGHT", 0, 0)
            menuButton:SetPoint("LEFT", guide, "LEFT", 0, 0)
            menuButton:SetPoint("RIGHT", guide, "RIGHT", 0, 0)
            menuButton:SetHeight(UI._menuButtonH or 28)
            UI._menuPlace = "between " .. a.text .. " and " .. b.text
            if UI._menuColor then UI._menuColor() end
            return
        end
    end
    menuButton:SetSize(UI._menuButtonW or 200, UI._menuButtonH or 28)
    menuButton:SetPoint("BOTTOM", gm, "TOP", 0, 24)
    local names = {}
    for i = 1, math.min(#list, 6) do names[#names + 1] = list[i].text end
    UI._menuPlace = "above the menu (Shop not found; buttons read: " .. #list
        .. (#names > 0 and (" - " .. table.concat(names, ", ")) or "") .. ")"
end
UI._PlaceMenuButton = PlaceMenuButton

function UI.UpdateMenuButton()
    if not menuButton then return end
    local gm = _G.GameMenuFrame
    local want = NS.db and W().menuButton ~= false
    local shown = false
    if gm then
        local ok, v = pcall(gm.IsShown, gm)
        shown = ok and not NS.IsSecret(v) and v == true
    end
    menuButton:SetShown(want and shown and true or false)
    if want and shown then
        pcall(PlaceMenuButton)
        -- the game lays its buttons out a moment after opening: place again then
        if C_Timer and C_Timer.After then
            for _, d in ipairs({ 0, 0.05, 0.15, 0.4, 1 }) do
                C_Timer.After(d, function()
                    pcall(PlaceMenuButton)
                    if d == 1 and not UI._menuReported then
                        UI._menuReported = true
                        NS.Print(string.format("Escape menu button: %s   (frames looked at %s)",
                            tostring(UI._menuPlace), tostring(UI._menuSeen)))
                    end
                end)
            end
        end
    end
end

function UI.SetupMenuButton()
    local gm = _G.GameMenuFrame
    if menuButton or not gm then return end
    -- the same button style the game's menu uses, so ours looks like one of its entries
    local ok, b
    for _, tpl in ipairs({ "MainMenuFrameButtonTemplate", "GameMenuButtonTemplate", "UIPanelButtonTemplate" }) do
        ok, b = pcall(CreateFrame, "Button", nil, UIParent, tpl)
        if ok and b then UI._menuTemplate = tpl; break end
    end
    if not ok or not b then ok, b = pcall(CreateFrame, "Button", "AimbotUIGameMenuButton", UIParent) end
    if not ok or not b then return end
    menuButton = b
    -- the style's own size is the game's button size (our own frame, so it can be read)
    local okW, w0 = pcall(b.GetWidth, b)
    local okH, h0 = pcall(b.GetHeight, b)
    UI._menuButtonW = (okW and not NS.IsSecret(w0) and type(w0) == "number" and w0 > 20) and w0 or 200
    UI._menuButtonH = (okH and not NS.IsSecret(h0) and type(h0) == "number" and h0 > 10) and h0 or 28
    b:SetSize(UI._menuButtonW, UI._menuButtonH)   -- never zero, or the button art breaks
    b:SetFrameStrata("FULLSCREEN_DIALOG")   -- above the menu itself
    b:SetPoint("BOTTOM", gm, "TOP", 0, 24)   -- until PlaceMenuButton lines it up in the list
    b:SetText("Aimbot UI")
    -- our own colour for the name (put back each time the button is shown, as the style resets it)
    local function Color()
        local fs = b.GetFontString and b:GetFontString()
        if fs then pcall(fs.SetTextColor, fs, 0.30, 0.72, 1.00) end
    end
    UI._menuColor = Color
    Color()
    b:HookScript("OnShow", Color)
    b:HookScript("OnLeave", Color)
    b:HookScript("OnMouseUp", Color)
    b:SetScript("OnClick", function()
        if InCombatLockdown and InCombatLockdown() then
            -- the Escape menu can't be closed for you in combat; open the window on top of it
            UI.Show()
            return
        end
        pcall(HideUIPanel, gm)
        UI.Show()
    end)
    b:Hide()
    pcall(gm.HookScript, gm, "OnShow", function() pcall(UI.UpdateMenuButton) end)
    pcall(gm.HookScript, gm, "OnHide", function() if menuButton then menuButton:Hide() end end)
    UI.UpdateMenuButton()
end
UI._menuButton = function() return menuButton end

SLASH_AIMBOTUI1 = "/aimbot"
SLASH_AIMBOTUI2 = "/aui"
SlashCmdList["AIMBOTUI"] = function(msg)
    if not NS.db then return end
    msg = (msg or ""):lower()
    local a, b = msg:match("^%s*(%S*)%s*(%S*)")
    if a == "" then UI.Toggle(); return end
    if a == "diag" or a == "diagnostics" or a == "check" then
        if NS.Diagnose then NS.Diagnose() end
        return
    end
    if a == "clean" or a == "clear" then
        local mm = NS.modules.memory
        if mm and mm.CleanNow then mm:CleanNow(true) else NS.Print("Memory Cleaner is not loaded.") end
        return
    end
    local key = ALIASES[a] or a
    if not UI.HasTab(key) then
        NS.Print("unknown tab '" .. a .. "'. Try: general, lorti, damage, flash, mana, range, trainer, double, memory, mute, fps, privacy, dr, queue, plates, combat, kick, death, repair, talent, timers, loc, autoshot  (or /aimbot clean)")
        return
    end
    if (b == "on" or b == "off") and NS.modules[key] then
        NS.Mod(key).enabled = (b == "on")
        NS.ApplyModule(key)
        UI.RefreshAll()
        NS.Print(NS.modules[key].name .. " " .. (b == "on" and "|cff00ff00ON|r" or "|cffff4444OFF|r"))
    else
        UI.Toggle(key)
    end
end

SLASH_AIMBOTSPARKLE1 = "/sparkle"
SlashCmdList["AIMBOTSPARKLE"] = function(msg)
    if not NS.db then return end
    local m = NS.Mod("sparkle")
    msg = (msg or ""):lower():match("^%s*(%S*)")
    if msg == "on" then m.enabled = true
    elseif msg == "off" then m.enabled = false
    elseif msg == "test" then
        if NS.modules.sparkle and NS.modules.sparkle.Test then NS.modules.sparkle:Test() end
        return
    else m.enabled = not m.enabled end
    NS.ApplyModule("sparkle")
    if win then UI.RefreshAll() end
    NS.Print("Button Flash " .. (m.enabled and "|cff00ff00ON|r" or "|cffff4444OFF|r"))
end

-- A small window with all the text selected, so it can be copied (Ctrl+C) and pasted anywhere.
function UI.ShowText(title, text)
    local f = UI._textWin
    if not f then
        f = CreateFrame("Frame", "AimbotUITextWindow", UIParent, "BackdropTemplate")
        f:SetSize(620, 380)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        f:SetMovable(true)
        f:EnableMouse(true)
        f:SetClampedToScreen(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        if f.SetBackdrop then
            f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
            f:SetBackdropColor(0.06, 0.06, 0.07, 0.97)
            f:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
        end
        f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        f.title:SetPoint("TOPLEFT", 12, -10)
        local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", 2, 2)
        local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("BOTTOMLEFT", 12, 10)
        hint:SetText("Click the text, press Ctrl+A then Ctrl+C to copy it.")
        local scroll = CreateFrame("ScrollFrame", "AimbotUITextWindowScroll", f, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 12, -34)
        scroll:SetPoint("BOTTOMRIGHT", -30, 32)
        local eb = CreateFrame("EditBox", nil, scroll)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject(ChatFontNormal or GameFontHighlight)
        eb:SetWidth(560)
        eb:SetScript("OnEscapePressed", function(self) self:ClearFocus(); f:Hide() end)
        scroll:SetScrollChild(eb)
        f.edit = eb
        if UISpecialFrames then tinsert(UISpecialFrames, "AimbotUITextWindow") end
        UI._textWin = f
    end
    f.title:SetText(title or "Aimbot UI")
    f.edit:SetText(text or "")
    f.edit:SetCursorPosition(0)
    f:Show()
    f.edit:SetFocus()
    f.edit:HighlightText()
end

-- Runs every module's optional Diagnose() so problems can be reported precisely.
-- The report is printed to chat, saved to the settings file (AimbotUIDB.lastDiag, written at
-- /reload or logout) and shown in a copy window.
function NS.Diagnose(quiet)
    local lines = {}
    NS.capture = lines
    local function Run()
        NS.Print("diagnostics (version " .. NS.version .. ", " .. tostring((select(4, GetBuildInfo()))) .. ")")
        NS.Print(string.format("Escape menu button: %s   (frames looked at %s, game buttons found %s)",
            tostring(UI._menuPlace or "not placed yet (open the Escape menu, then run this again)"),
            tostring(UI._menuSeen or "-"), tostring(UI._menuFound or "-")))
        for _, key in ipairs(NS.moduleOrder) do
            local m = NS.modules[key]
            NS.Print("|cff4db8ff" .. (m.name or key) .. "|r  " ..
                (NS.Mod(key).enabled and "|cff00ff00on|r" or "|cffff4444off|r"))
            if m.Diagnose then
                local ok, err = pcall(m.Diagnose, m)
                if not ok then NS.ReportError((m.name or key) .. " diagnose", err) end
            end
        end
    end
    local ok, err = pcall(Run)
    NS.capture = nil
    if not ok then NS.ReportError("diagnostics", err) end
    if NS.db then
        NS.db.lastDiag = { version = NS.version, time = date and date("%Y-%m-%d %H:%M:%S") or "", lines = lines }
    end
    if not quiet then
        NS.Print("Saved to your settings file (lastDiag) and shown in a copy window.")
        UI.ShowText("Aimbot UI diagnostics", table.concat(lines, "\n"))
    end
end
