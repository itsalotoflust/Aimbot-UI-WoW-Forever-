local _, wt = ...
local class = wt.forClass("WARLOCK")

class.spellsByLevel = {
	[1] = {{id = 348, cost = 10}},
	[4] = {{id = 172, cost = 100}, {id = 702, cost = 100}},
	[6] = {{id = 1454, cost = 100}, {id = 695, cost = 100, requiredIds = {686}}},
	[8] = {{id = 980, cost = 200}, {id = 5782, cost = 200}},
	[10] = {
		{id = 6201, cost = 300, requiredIds = {1120}},
		{id = 696, cost = 300, requiredIds = {687}},
		{id = 1120, cost = 300},
		{id = 707, cost = 300, requiredIds = {348}}
	},
	[12] = {
		{id = 1108, cost = 800, requiredIds = {702}},
		{id = 755, cost = 800},
		{id = 705, cost = 800, requiredIds = {695}}
	},
	[14] = {{id = 6222, cost = 1000, requiredIds = {172}}, {id = 704, cost = 1000}, {id = 689, cost = 1000}},
	[16] = {{id = 1455, cost = 1600, requiredIds = {1454}}, {id = 5697, cost = 1600}},
	[18] = {
		{id = 1014, cost = 1700, requiredIds = {980}},
		{id = 693, cost = 1700, requiredIds = {1120}},
		{id = 5676, cost = 1700}
	},
	[20] = {
		{id = 440892, cost = 2500},
		{id = 706, cost = 2500},
		{id = 3698, cost = 2500, requiredIds = {755}},
		{id = 1094, cost = 2500, requiredIds = {707}},
		{id = 5740, cost = 2500},
		{id = 698, cost = 2500},
		{id = 1088, cost = 2500, requiredIds = {705}}
	},
	[22] = {
		{id = 6202, cost = 3800, requiredIds = {6201}},
		{id = 6205, cost = 3800, requiredIds = {1108}},
		{id = 699, cost = 3800, requiredIds = {689}},
		{id = 126, cost = 3800}
	},
	[24] = {
		{id = 6223, cost = 4800, requiredIds = {6222}},
		{id = 5138, cost = 4800},
		{id = 8288, cost = 4800, requiredIds = {1120}},
		{id = 5500, cost = 4800},
		{id = 18867, cost = 4800, requiredIds = {17877}, requiredTalentId = 17877}
	},
	[26] = {
		{id = 1714, cost = 5000},
		{id = 132, cost = 5000},
		{id = 1456, cost = 5000, requiredIds = {1455}},
		{id = 17919, cost = 5000, requiredIds = {5676}}
	},
	[28] = {
		{id = 6217, cost = 6000, requiredIds = {1014}},
		{id = 710, cost = 6000},
		{id = 6366, cost = 6000},
		{id = 7658, cost = 6000, requiredIds = {704}},
		{id = 3699, cost = 6000, requiredIds = {3698}},
		{id = 1106, cost = 6000, requiredIds = {1088}}
	},
	[30] = {
		{id = 20752, cost = 7000, requiredIds = {693}},
		{id = 1311676, cost = 7000, requiredIds = {440892}},
		{id = 1086, cost = 7000, requiredIds = {706}},
		{id = 709, cost = 7000, requiredIds = {699}},
		{id = 1949, cost = 7000},
		{id = 2941, cost = 7000, requiredIds = {1094}},
		{id = 1098, cost = 7000}
	},
	[32] = {
		{id = 1293818, cost = 8000, requiredIds = {1293817}, requiredTalentId = 1293817},
		{id = 7646, cost = 8000, requiredIds = {6205}},
		{id = 6213, cost = 8000, requiredIds = {5782}},
		{id = 6229, cost = 8000},
		{id = 18868, cost = 8000, requiredIds = {18867}, requiredTalentId = 17877}
	},
	[34] = {
		{id = 7648, cost = 9000, requiredIds = {6223}},
		{id = 5699, cost = 9000, requiredIds = {6202}},
		{id = 6226, cost = 9000, requiredIds = {5138}},
		{id = 6219, cost = 9000, requiredIds = {5740}},
		{id = 17920, cost = 9000, requiredIds = {17919}}
	},
	[36] = {
		{id = 17951, cost = 10000, requiredIds = {6366}},
		{id = 2362, cost = 10000, requiredIds = {1120}},
		{id = 3700, cost = 10000, requiredIds = {3699}},
		{id = 11687, cost = 10000, requiredIds = {1456}},
		{id = 7641, cost = 10000, requiredIds = {1106}}
	},
	[38] = {
		{id = 11711, cost = 11000, requiredIds = {6217}},
		{id = 2970, cost = 11000, requiredIds = {132}},
		{id = 7651, cost = 11000, requiredIds = {709}},
		{id = 8289, cost = 11000, requiredIds = {8288}},
		{id = 18879, cost = 11000, requiredIds = {18265}, requiredTalentId = 18265}
	},
	[40] = {
		{id = 17962, cost = 14000, requiredIds = {1293818}, requiredTalentId = 1293817},
		{id = 20755, cost = 14000, requiredIds = {20752}},
		{id = 1311677, cost = 14000, requiredIds = {1311676}},
		{id = 11733, cost = 14000, requiredIds = {1086}},
		{id = 5484, cost = 14000},
		{id = 11665, cost = 14000, requiredIds = {2941}},
		{id = 18869, cost = 14000, requiredIds = {18868}, requiredTalentId = 17877}
	},
	[42] = {
		{id = 7659, cost = 15000, requiredIds = {7658}},
		{id = 11707, cost = 15000, requiredIds = {7646}},
		{id = 6789, cost = 15000},
		{id = 11683, cost = 15000, requiredIds = {1949}},
		{id = 17921, cost = 15000, requiredIds = {17920}},
		{id = 11739, cost = 15000, requiredIds = {6229}}
	},
	[44] = {
		{id = 11671, cost = 16000, requiredIds = {7648}},
		{id = 11703, cost = 16000, requiredIds = {6226}},
		{id = 11693, cost = 16000, requiredIds = {3700}},
		{id = 11659, cost = 16000, requiredIds = {7641}},
		{id = 11725, cost = 16000, requiredIds = {1098}}
	},
	[46] = {
		{id = 17952, cost = 20000, requiredIds = {17951}},
		{id = 11729, cost = 20000, requiredIds = {5699}},
		{id = 11699, cost = 20000, requiredIds = {7651}},
		{id = 11688, cost = 20000, requiredIds = {11687}},
		{id = 11677, cost = 20000, requiredIds = {6219}}
	},
	[48] = {
		{id = 11712, cost = 21000, requiredIds = {11711}},
		{id = 18647, cost = 21000, requiredIds = {710}},
		{id = 18930, cost = 21000, requiredIds = {17962}, requiredTalentId = 1293817},
		{id = 17727, cost = 21000, requiredIds = {2362}},
		{id = 18870, cost = 21000, requiredIds = {18869}, requiredTalentId = 17877},
		{id = 18880, cost = 21000, requiredIds = {18879}, requiredTalentId = 18265},
		{id = 6353, cost = 21000}
	},
	[50] = {
		{id = 20756, cost = 22000, requiredIds = {20755}},
		{id = 1311680, cost = 22000, requiredIds = {1311677}},
		{id = 11719, cost = 22000, requiredIds = {1714}},
		{id = 17925, cost = 22000, requiredIds = {6789}},
		{id = 11734, cost = 22000, requiredIds = {11733}},
		{id = 11743, cost = 22000, requiredIds = {2970}},
		{id = 11667, cost = 22000, requiredIds = {11665}},
		{id = 1293812, cost = 22000, requiredIds = {412758}, requiredTalentId = 412758},
		{id = 17922, cost = 22000, requiredIds = {17921}}
	},
	[52] = {
		{id = 11708, cost = 23000, requiredIds = {11707}},
		{id = 11675, cost = 23000, requiredIds = {8289}},
		{id = 11694, cost = 23000, requiredIds = {11693}},
		{id = 11660, cost = 23000, requiredIds = {11659}},
		{id = 11740, cost = 23000, requiredIds = {11739}}
	},
	[54] = {
		{id = 18931, cost = 24000, requiredIds = {18930}, requiredTalentId = 1293817},
		{id = 11672, cost = 24000, requiredIds = {11671}},
		{id = 11700, cost = 24000, requiredIds = {11699}},
		{id = 11704, cost = 24000, requiredIds = {11703}},
		{id = 11684, cost = 24000, requiredIds = {11683}},
		{id = 17928, cost = 24000, requiredIds = {5484}}
	},
	[56] = {
		{id = 17953, cost = 25000, requiredIds = {17952}},
		{id = 11717, cost = 25000, requiredIds = {7659}},
		{id = 6215, cost = 25000, requiredIds = {6213}},
		{id = 11689, cost = 25000, requiredIds = {11688}},
		{id = 18871, cost = 25000, requiredIds = {18870}, requiredTalentId = 17877},
		{id = 17924, cost = 25000, requiredIds = {6353}}
	},
	[58] = {
		{id = 11713, cost = 26000, requiredIds = {11712}},
		{id = 11730, cost = 26000, requiredIds = {11729}},
		{id = 17926, cost = 26000, requiredIds = {17925}},
		{id = 11678, cost = 26000, requiredIds = {11677}},
		{id = 17923, cost = 26000, requiredIds = {17922}},
		{id = 18881, cost = 26000, requiredIds = {18880}, requiredTalentId = 18265},
		{id = 11726, cost = 26000, requiredIds = {11725}}
	},
	[60] = {
		{id = 603, cost = 27000},
		{id = 18932, cost = 27000, requiredIds = {18931}, requiredTalentId = 1293817},
		{id = 20757, cost = 27000, requiredIds = {20756}},
		{id = 17728, cost = 27000, requiredIds = {17727}},
		{id = 11735, cost = 27000, requiredIds = {11734}},
		{id = 11695, cost = 27000, requiredIds = {11694}},
		{id = 11668, cost = 27000, requiredIds = {11667}},
		{id = 1293813, cost = 27000, requiredIds = {1293812}, requiredTalentId = 412758},
		{id = 11661, cost = 27000, requiredIds = {11660}}
	}
}
