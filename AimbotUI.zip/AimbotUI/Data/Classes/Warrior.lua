local _, wt = ...
local class = wt.forClass("WARRIOR")

local battleShout = {6673, 5242, 6192, 11549, 11550, 11551}
local charge = {100, 6178, 11578}
local rend = {772, 6546, 6547, 6548, 11572, 11573, 11574}
local thunderClap = {6343, 8198, 8204, 8205, 11580, 11581}
local hamstring = {1715, 7372, 7373}
local heroicStrike = {78, 284, 285, 1608, 11564, 11565, 11566, 11567}
local overpower = {7384, 7887, 11584, 11585}
local shieldBash = {72, 1671, 1672}
local demoralizingShout = {1160, 6190, 11554, 11555, 11556}
local revenge = {6572, 6574, 7379, 11600, 11601}
local mockingBlow = {694, 7400, 7402, 20559, 20560}
local cleave = {845, 7369, 11608, 11609, 20569}
local slam = {1240193, 1464, 8820, 11604, 11605}
local sunderArmor = {7386, 7405, 8380, 11596, 11597}
local execute = {5308, 20658, 20660, 20661, 20662}
local pummel = {6552, 6554}
local intercept = {20252, 20616, 20617}
local bloodthirst = {23881, 23892, 23893, 23894}
local mortalStrike = {12294, 21551, 21552, 21553}
local shieldSlam = {23922, 23923, 23924, 23925}

class.overriddenGroups = {
	battleShout,
	charge,
	rend,
	thunderClap,
	hamstring,
	heroicStrike,
	overpower,
	shieldBash,
	demoralizingShout,
	revenge,
	mockingBlow,
	cleave,
	slam,
	sunderArmor,
	execute,
	pummel,
	intercept,
	bloodthirst,
	mortalStrike,
	shieldSlam
}

class.spellsByLevel = {
	[1] = {{id = 6673, cost = 10}},
	[4] = {{id = 100, cost = 100}, {id = 772, cost = 100}},
	[6] = {{id = 3127, cost = 100}, {id = 6343, cost = 100}},
	[8] = {{id = 1715, cost = 200}, {id = 284, cost = 200, requiredIds = {78}}},
	[10] = {{id = 2687, cost = 700}, {id = 6546, cost = 700, requiredIds = {772}}},
	[12] = {{id = 5242, cost = 900, requiredIds = {6673}}, {id = 7384, cost = 900}, {id = 72, cost = 900}},
	[14] = {{id = 1160, cost = 1100}, {id = 6572, cost = 1100, requiredIds = {71}}, {id = 1310185, cost = 1100}},
	[16] = {
		{id = 285, cost = 1500, requiredIds = {284}},
		{id = 694, cost = 1500},
		{id = 2565, cost = 1500, requiredIds = {71}}
	},
	[18] = {{id = 676, cost = 3200, requiredIds = {71}}, {id = 8198, cost = 3200, requiredIds = {6343}}},
	[20] = {
		{id = 845, cost = 3400},
		{id = 674, cost = 3400},
		{id = 6547, cost = 3400, requiredIds = {6546}},
		{id = 20230, cost = 3400},
		{id = 1240193, cost = 3400},
		{id = 402927, cost = 3400}
	},
	[22] = {
		{id = 6192, cost = 5500, requiredIds = {5242}},
		{id = 5246, cost = 5500},
		{id = 7405, cost = 5500, requiredIds = {7386}}
	},
	[24] = {
		{id = 6190, cost = 6400, requiredIds = {1160}},
		{id = 5308, cost = 6400},
		{id = 1608, cost = 6400, requiredIds = {285}},
		{id = 6574, cost = 6400, requiredIds = {6572}}
	},
	[26] = {
		{id = 1161, cost = 7600},
		{id = 6178, cost = 7600, requiredIds = {100}},
		{id = 7400, cost = 7600, requiredIds = {694}}
	},
	[28] = {
		{id = 7887, cost = 11000, requiredIds = {7384}},
		{id = 871, cost = 11000, requiredIds = {71}},
		{id = 8204, cost = 11000, requiredIds = {8198}}
	},
	[30] = {
		{id = 18499, cost = 12000, requiredIds = {2458}},
		{id = 7369, cost = 12000, requiredIds = {845}},
		{id = 6548, cost = 12000, requiredIds = {6547}},
		{id = 1464, cost = 12000, requiredIds = {1240193}}
	},
	[32] = {
		{id = 11549, cost = 13000, requiredIds = {6192}},
		{id = 20658, cost = 13000, requiredIds = {5308}},
		{id = 7372, cost = 13000, requiredIds = {1715}},
		{id = 11564, cost = 13000, requiredIds = {1608}},
		{id = 1671, cost = 13000, requiredIds = {72}}
	},
	[34] = {
		{id = 11554, cost = 14000, requiredIds = {6190}},
		{id = 7379, cost = 14000, requiredIds = {6574}},
		{id = 8380, cost = 14000, requiredIds = {7405}}
	},
	[36] = {{id = 7402, cost = 18000, requiredIds = {7400}}, {id = 1680, cost = 18000, requiredIds = {2458}}},
	[38] = {
		{id = 6552, cost = 19000, requiredIds = {2458}},
		{id = 8820, cost = 19000, requiredIds = {1464}},
		{id = 8205, cost = 19000, requiredIds = {8204}}
	},
	[40] = {
		{id = 11608, cost = 23000, requiredIds = {7369}},
		{id = 20660, cost = 23000, requiredIds = {20658}},
		{id = 11565, cost = 23000, requiredIds = {11564}},
		{id = 750, cost = 23000},
		{id = 11572, cost = 23000, requiredIds = {6548}}
	},
	[42] = {{id = 11550, cost = 30000, requiredIds = {11549}}, {id = 20616, cost = 30000, requiredIds = {20252}}},
	[44] = {
		{id = 11555, cost = 31000, requiredIds = {11554}},
		{id = 11584, cost = 31000, requiredIds = {7887}},
		{id = 11600, cost = 31000, requiredIds = {7379}}
	},
	[46] = {
		{id = 11578, cost = 32000, requiredIds = {6178}},
		{id = 20559, cost = 32000, requiredIds = {7402}},
		{id = 11604, cost = 32000, requiredIds = {8820}},
		{id = 11596, cost = 32000, requiredIds = {8380}}
	},
	[48] = {
		{id = 23892, cost = 33000, requiredIds = {23881}, requiredTalentId = 23881},
		{id = 20661, cost = 33000, requiredIds = {20660}},
		{id = 11566, cost = 33000, requiredIds = {11565}},
		{id = 21551, cost = 33000, requiredIds = {12294}, requiredTalentId = 12294},
		{id = 23923, cost = 33000, requiredIds = {23922}, requiredTalentId = 23922},
		{id = 11580, cost = 33000, requiredIds = {8205}}
	},
	[50] = {
		{id = 11609, cost = 36000, requiredIds = {11608}},
		{id = 1719, cost = 36000, requiredIds = {2458}},
		{id = 11573, cost = 36000, requiredIds = {11572}}
	},
	[52] = {
		{id = 11551, cost = 39000, requiredIds = {11550}},
		{id = 20617, cost = 39000, requiredIds = {20616}},
		{id = 1672, cost = 39000, requiredIds = {1671}}
	},
	[54] = {
		{id = 23893, cost = 40000, requiredIds = {23892}, requiredTalentId = 23881},
		{id = 11556, cost = 40000, requiredIds = {11555}},
		{id = 7373, cost = 40000, requiredIds = {7372}},
		{id = 21552, cost = 40000, requiredIds = {21551}, requiredTalentId = 12294},
		{id = 11601, cost = 40000, requiredIds = {11600}},
		{id = 23924, cost = 40000, requiredIds = {23923}, requiredTalentId = 23922},
		{id = 11605, cost = 40000, requiredIds = {11604}}
	},
	[56] = {
		{id = 20662, cost = 42000, requiredIds = {20661}},
		{id = 11567, cost = 42000, requiredIds = {11566}},
		{id = 20560, cost = 42000, requiredIds = {20559}}
	},
	[58] = {
		{id = 6554, cost = 48000, requiredIds = {6552}},
		{id = 11597, cost = 48000, requiredIds = {11596}},
		{id = 11581, cost = 48000, requiredIds = {11580}}
	},
	[60] = {
		{id = 23894, cost = 49000, requiredIds = {23893}, requiredTalentId = 23881},
		{id = 20569, cost = 49000, requiredIds = {11609}},
		{id = 21553, cost = 49000, requiredIds = {21552}, requiredTalentId = 12294},
		{id = 11585, cost = 49000, requiredIds = {11584}},
		{id = 11574, cost = 49000, requiredIds = {11573}},
		{id = 23925, cost = 49000, requiredIds = {23924}, requiredTalentId = 23922}
	}
}
